# Replication code

## Movie S1 and three-dimensional intraday profiles

Run from the repository or replication-package root, with `SPX_DATA_FILE`
set to the licensed minute-data path:

```sh
Rscript reproducibility/code/empirical/build_spx_3d_multimedia.R
```

This generates the two-panel MP4 and static views in `multimedia/`.
It checks reconstructed FPCA scores against the saved continuous analysis
and reads the first-alarm dates from those results. It does not re-estimate
the monitors or simulate new critical values. Full specifications and
options are in `multimedia/README.md` at the package root. Use
`--video=false` to generate only PNGs without ffmpeg.

This directory contains the implementation and scripts used for the revised
retained-score monitoring paper. Run commands from this `code` directory.

The complete file-to-result map and directory overview are in
[the replication-materials README](../README.md). They replace the detailed
file inventory previously printed in supplementary Appendix F.

## Core implementation

- `R/dual_channel_monitor.R` implements the lag-zero LDL triangular demixing,
  componentwise adjusted-range monitor, and Shao's quadratic
  self-normalization benchmark.
- `R/intraday_interface.R` converts licensed minute OHLC observations into
  daily smoothed log realized-variance curves.
- `tests/test_dual_channel_monitor.R` checks LDL reconstruction, the
  quadratic-SN affine-invariance and rank identities, fitted FPCA projection,
  and the paired adjusted-range and quadratic-SN monitoring paths. The legacy
  filename is retained for compatibility.

The manuscript-facing specification fixes the unweighted boundary
`(1 + s)^2`, corresponding to `gamma = 0`. The general `gamma` argument and
the `gamma` fields in saved result files are retained for
backward compatibility; no nonzero value is analyzed in the paper. The core
implementation file also retains older dual-channel, orthogonal-audit, and
affine-range helpers for backward compatibility. None of those extensions is
called by the paper-facing simulation or empirical scripts.

## Paper simulations

- `simulations/componentwise_range/run_shao_comparison.R` runs the paired null,
  power, and delay comparison with 5,000 replications per cell. The filename is
  retained for compatibility; the paper calls the comparator Shao's
  quadratic self-normalization.
- `run_critical_value_audit.R` produces the 250,000-path exact-grid Brownian
  critical values and 50,000-path grid checks.
- `run_post_ldl_correlation_sweep.R` varies controlled post-LDL long-run
  correlation.
- `run_k4_short_horizon_audit.R` checks size at the empirical dimension and
  horizon.
- `run_boundary_fve_pc3_power.R` examines a shift omitted or retained according
  to random FVE selection.
- `run_near_eigengap_audit.R` evaluates null size and PC2/PC3 power when the
  second and third eigenvalues are close.

The saved numerical results used in the manuscript are in `../data/`.
Full Monte Carlo runs are computationally intensive; the supplied CSV files
allow the reported tables to be checked without rerunning every simulation.

## Empirical analysis

- `empirical/run_spx_range_vs_shao.R` runs the shared-fit 2014--2020 analysis
  and automatically reads the packaged exact-grid critical-value audit.
- `empirical/run_spx_robustness_audit.R` produces reference-period summaries,
  the historical 2019 monitoring exercise, preprocessing comparisons, and
  reconstruction metadata.
- `empirical/build_spx_interpretation_checks.R` regenerates the retained
  eigenfunction figure, fixed-dimension monitoring results, and alarm-coordinate
  decompositions from the saved primary-analysis object; it does not require
  the licensed minute-level source file.

The licensed minute-level source file is not redistributed. Supply its path
through `SPX_DATA_FILE` when rerunning the empirical scripts.

## Minimal code check

```sh
Rscript tests/test_dual_channel_monitor.R
```

The paper's core calculations use base R. The complete test script also
requires `lpSolve` for legacy convex-hull helper tests; these helpers are
not used by the paper's monitoring procedure. The intraday interface uses
`data.table`, and generating Movie S1 additionally requires `ffmpeg`.

## Different-regime simulations and supplementary empirical comparisons

The following commands are run from the manuscript directory (two levels
above this README), not from `reproducibility/code`:

```sh
Rscript reproducibility/code/simulations/componentwise_range/run_nonidentity_ldl_study.R 5000 6
Rscript reproducibility/code/empirical/complete_pro_review_checks.R
Rscript reproducibility/code/empirical/build_pro_review_tables.R
Rscript reproducibility/code/empirical/plot_readable_power_panels.R
```

The first command runs all six specified different-regime null designs,
retaining every replication and all four methods. It also records the exact
rotation matrix and population covariance/LRV matrices. The oracle uses the
known limiting fit basis and population LDL map; it is not a deployable test.
The eight-dimensional DGP generator now reads that archived rotation relative
to its own source location. It therefore does not recompute an unspecified
rank-deficient QR completion on each platform. The stored matrix agrees with
the original implementation to less than 5e-16 in every entry.

The second command uses the saved empirical score object, not the licensed
minute records. It recovers the original preprocessing critical values with
the original seeds/cache order, reports alarm sensitivity to primary
critical-value Monte Carlo intervals, saves original and demixed loadings,
and evaluates all three stated reference-window comparisons. Each new
window uses 250,000 paired Brownian draws. The maxima are retained under
`empirical/outputs/pro_review_checks`, and re-running uses those caches.
The saved 2014--2015 basis and 2020 data are held fixed in these post hoc
window comparisons. These comparisons concern the earlier 2020-only
specification in Appendix E. The primary continuous 2019--2020 specification
is described below.

The final two commands regenerate the added tables and the enlarged power
figures from the CSV files. Numerical changes are not made by those builders.
After running the older root-level `build_revised_tables.R`, run these two
commands again to reproduce the final presentation. The old five-column
power PNG is retained for provenance but is no longer used by the main paper.

The primary new data files are `nonidentity_ldl_null_5000rep.csv`,
`fixed_functional_rotation_8.csv`, `spx_preprocessing_complete.csv`,
`spx_original_and_demixed_loadings.csv`, `spx_inverse_ldl_matrix.csv`,
`spx_critical_value_alarm_sensitivity.csv`,
`spx_reference_window_sensitivity.csv` and `spx_reference_window_paths.csv`
under `reproducibility/data` in the manuscript directory. Pre-change alarm
probabilities and common risk-set counts are taken from the original paired
power summary files, not from a new power simulation.

## Continuous 2019--2020 application (7 September 2026)

The main application now retains the 2014--2015 FPCA fit, re-estimates reference
quantities on 2016--2018, and monitors all 500 retained observations in 2019--2020
without a January 2020 reset. From the manuscript directory, run:

```sh
Rscript reproducibility/code/empirical/run_spx_continuous_2019_2020.R
Rscript reproducibility/code/empirical/check_spx_continuous_outputs.R
Rscript reproducibility/code/empirical/build_spx_continuous_outputs.R
```

The first script uses the saved FPCA score object and does not read or modify
licensed minute records. It reconstructs the original scores, re-estimates all
reference quantities, and uses 250,000 paired matched-grid Brownian draws for
each of three fixed designs: the continuous application, 2016--2017 reference
with 2018 monitoring, and 2016 reference with 2017--2018 monitoring. The two
reference checks are not used to search for or select a new reference period.
Six workers process seeded chunks. Brownian maxima and fitted objects are
cached under `empirical/outputs/continuous_2019_2020/`; the CSV outputs have prefix
`spx_continuous_` in `reproducibility/data/`. The check script verifies Brownian
draws against the existing statistic implementation, common-centering invariance,
and first-crossing inequalities. The runner also verifies the unchanged 2019
statistic prefix against the earlier one-year calculation.

The resulting continuous alarm dates are 25 March and 4 May 2020. Quadratic SN
also crosses during the internal 2018 reference check; the shorter reference
sample is therefore not described as empirically validated stable history.
The previous 2020-only files and their sensitivity comparisons remain unchanged
and are reported separately in supplementary Appendix E, not as results for the
new reference period or two-year horizon.

Compile the main paper and supplement sequentially. Each imports the other's
`.aux` file, so simultaneous compilation can read an incomplete cross-reference
file. A main--supplement--main sequence resolves both directions.
