#!/usr/bin/env Rscript
# ---------------------------------------------------------------------------
# Paired benchmark of six monitoring statistics on one score stream.
#   adjusted_range : proposed adjusted-range self-normalized statistic
#   quadratic      : quadratic SN benchmark (Shao 2010 principle; Chan et al. 2021)
#   cusum          : HAC CUSUM,          boundary (1+s)^2
#   weighted       : HAC weighted CUSUM, boundary (1+s)^2 (s/(1+s))^(2*0.45)
#   page           : HAC Page-CUSUM,     scan over segment start points
#   mosum          : HAC multiscale MOSUM, H = {0.05, 0.10, 0.20}
# Within a replication all six use identical curves, FPCA fit, selected K,
# LDL transformation, monitoring observations and change.  Only the statistic,
# its scale estimate and its matched-grid critical value differ.
# ---------------------------------------------------------------------------
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
project_dir <- normalizePath(file.path(script_dir, "../.."))
paper_dir <- normalizePath(file.path(project_dir, ".."))
source(file.path(project_dir, "R", "dual_channel_monitor.R"))
source(file.path(project_dir, "simulations", "formal", "R", "null_dgp.R"))
source(file.path(script_dir, "detector_shapes.R"))

args <- list(nrep = 5000L, workers = 11L, chunk = 250L, seed = 20260830L,
             bandwidth = 10L, stage = "all")
for (a in commandArgs(trailingOnly = TRUE)) {
  kv <- strsplit(sub("^--", "", a), "=", fixed = TRUE)[[1L]]
  args[[kv[1L]]] <- if (kv[1L] == "stage") kv[2L] else as.integer(kv[2L])
}
METHODS <- c("adjusted_range", "quadratic", "cusum", "weighted", "page", "mosum")
out_dir <- file.path(script_dir, "outputs", "detector_benchmark")
ckpt_dir <- file.path(script_dir, "checkpoints",
                      sprintf("detector_bm_b%d_s%d", args$bandwidth, args$seed))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
data_dir <- file.path(paper_dir, "data")

## ---- critical values ------------------------------------------------------
cv_det <- utils::read.csv(file.path(data_dir, "detector_benchmark_critical_values.csv"),
                          stringsAsFactors = FALSE)
cv_sn <- utils::read.csv(file.path(data_dir,
  "critical_value_grid_and_monte_carlo_checks.csv"), stringsAsFactors = FALSE)
cv_lookup <- function(config, K) {
  d <- cv_det[cv_det$configuration == config & cv_det$K == K, ]
  sn_cfg <- if (config == "exact1000_500_T0.5") "exact1000_500_T0.5" else "exact997_251_empirical"
  s <- cv_sn[cv_sn$configuration == sn_cfg & cv_sn$K == K, ]
  out <- c(adjusted_range = s$critical_value[s$method_id == "adjusted_range"],
           quadratic      = s$critical_value[s$method_id == "full_matrix"])
  for (nm in c("cusum", "weighted", "page", "mosum")) out[nm] <- d$critical_value[d$detector == nm]
  out[METHODS]
}

## ---- scenarios ------------------------------------------------------------
scenario <- function(id, design, panel, eigen_profile = "fixed",
                     K_mode = "fixed", K_fixed = 2L) {
  list(id = id, design = design, panel = panel, eigen_profile = eigen_profile,
       K_mode = K_mode, K_fixed = as.integer(K_fixed), fve = 0.90, d_grid = 8L,
       m_fit = 500L, m_calibration = 1000L, m_monitor = 500L, alpha = 0.05,
       prewhiten_mode = "demix", ldl_ridge = 1e-8, feature_var_order = 0L)
}
null_scenarios <- list(
  scenario("primary_gaussian_iid", "gaussian_iid", "primary"),
  scenario("primary_hong_diag_var", "hong_var_diag", "primary"),
  scenario("primary_component_lrv", "component_ar_lrv", "primary"),
  scenario("primary_component_garch", "component_garch", "primary"),
  scenario("primary_component_sv", "component_sv", "primary"),
  scenario("primary_component_t5", "component_t5", "primary"),
  scenario("primary_randomK_stable", "component_ar_lrv", "primary",
           eigen_profile = "fve_stable", K_mode = "random_fve"),
  scenario("primary_randomK_boundary", "component_ar_lrv", "primary",
           eigen_profile = "fve_boundary", K_mode = "random_fve"),
  scenario("stress_hong_cross_var", "hong_var_cross", "stress"),
  scenario("stress_hong_cross_garch", "hong_garch", "stress"),
  scenario("stress_general_nondiag_lrv", "nondiag_lrv", "stress"),
  scenario("stress_common_persistent_garch", "garch", "stress"),
  scenario("stress_common_persistent_sv", "sv", "stress"),
  scenario("stress_general_t5", "heavy_t5", "stress"),
  scenario("stress_general_t3", "heavy_t3_stress", "stress"))
names(null_scenarios) <- vapply(null_scenarios, `[[`, "", "id")
NULL_ID <- c(gaussian_iid = "primary_gaussian_iid",
             hong_var_diag = "primary_hong_diag_var",
             component_garch = "primary_component_garch",
             component_sv = "primary_component_sv",
             component_t5 = "primary_component_t5")

## Panel I: the moderate-signal cells already used in the manuscript.
panelI_specs <- rbind(
  expand.grid(design = names(NULL_ID), direction = c("sparse_first", "dense_first_two"),
              delta = 0.15, mechanism = "abrupt", stringsAsFactors = FALSE),
  expand.grid(design = c("hong_var_diag", "component_garch", "component_t5"),
              direction = "sparse_first", delta = 0.40, mechanism = "ramp",
              stringsAsFactors = FALSE))

## Panel II: prespecified change mechanisms at equal signal energy.
## Energy E = sum_t w_t^2 * delta^2 over the 500-observation monitoring window,
## fixed at E = 0.15^2 * 450 (the early-permanent reference case).
MECH <- list(
  early_permanent = list(start = 50L,  shape = "step"),
  late_permanent  = list(start = 350L, shape = "step"),
  epidemic        = list(start = 150L, shape = "epidemic", stop = 250L),
  ramp            = list(start = 100L, shape = "ramp"))
mech_weights <- function(mech, n_monitor = 500L) {
  w <- numeric(n_monitor)
  spec <- MECH[[mech]]
  idx <- seq.int(spec$start + 1L, n_monitor)
  if (spec$shape == "step") w[idx] <- 1
  if (spec$shape == "epidemic") w[seq.int(spec$start + 1L, spec$stop)] <- 1
  if (spec$shape == "ramp") w[idx] <- seq_along(idx) / length(idx)
  w
}
ENERGY <- 0.15^2 * 450
mech_delta <- function(mech) sqrt(ENERGY / sum(mech_weights(mech)^2))
panelII_specs <- expand.grid(
  design = c("gaussian_iid", "hong_var_diag", "component_garch"),
  mechanism = names(MECH), direction = "sparse_first",
  stringsAsFactors = FALSE)
panelII_specs$delta <- vapply(panelII_specs$mechanism, mech_delta, 0)

make_power <- function(specs, panel) lapply(seq_len(nrow(specs)), function(i) {
  r <- specs[i, ]
  sc <- scenario(sprintf("%s_%s_%s_%s_d%0.4f", panel, r$mechanism, r$design,
                         r$direction, r$delta), r$design, panel)
  sc$direction <- r$direction; sc$delta <- as.numeric(r$delta)
  sc$mechanism <- r$mechanism; sc$null_scenario_id <- unname(NULL_ID[[r$design]])
  sc
})
power_scenarios <- c(make_power(panelI_specs, "panelI"),
                     make_power(panelII_specs, "panelII"))

## ---- one replication ------------------------------------------------------
shift_vector <- function(sc) {
  lambda <- dc_score_eigenvalues(sc$d_grid, profile = sc$eigen_profile)
  rotation <- if (sc$design == "gaussian_iid") diag(sc$d_grid) else
    dc_functional_basis_rotation(sc$d_grid)
  direction <- if (sc$direction == "sparse_first") c(1, rep(0, sc$K_fixed - 1L)) else
    rep(1 / sqrt(sc$K_fixed), sc$K_fixed)
  as.numeric((sc$delta * direction * sqrt(lambda[seq_len(sc$K_fixed)])) %*%
               rotation[seq_len(sc$K_fixed), , drop = FALSE])
}

run_one <- function(sc, x, cv_config = "exact1000_500_T0.5") {
  fit_i <- seq_len(sc$m_fit)
  ref_i <- sc$m_fit + seq_len(sc$m_calibration)
  mon_i <- sc$m_fit + sc$m_calibration + seq_len(sc$m_monitor)
  fitted <- dc_fit_score_comparison(
    x[fit_i, , drop = FALSE], x[ref_i, , drop = FALSE],
    K = if (sc$K_mode == "fixed") sc$K_fixed else NULL, fve = sc$fve,
    K_max = 5L, prewhiten_mode = sc$prewhiten_mode, ldl_ridge = sc$ldl_ridge,
    sn_ridge = 0, feature_var_order = sc$feature_var_order)
  K <- fitted$settings$K
  cv <- cv_lookup(cv_config, K)
  sn <- dc_monitor_score_comparison(fitted, x[mon_i, , drop = FALSE],
    alpha = sc$alpha, gamma = 0,
    critical_values = c(adjusted_range = cv[["adjusted_range"]],
                        shao = cv[["quadratic"]]))
  hac <- det_bartlett_lrv(fitted$adjusted_range$calibration_sn_scores,
                          bandwidth = args$bandwidth)
  proj <- dc_project_fpca(fitted$adjusted_range$fpca, x[mon_i, , drop = FALSE])
  mon_feat <- dc_apply_var_ldl_features(
    fitted$adjusted_range$feature_prewhitener,
    dc_apply_ldl_prewhitener(fitted$adjusted_range$prewhitener, proj$retained))
  det <- det_paths(hac, mon_feat)
  paths <- list(adjusted_range = sn$path$adjusted_range, quadratic = sn$path$shao,
                cusum = det$cusum, weighted = det$weighted,
                page = det$page, mosum = det$mosum)
  list(K = K, paths = paths, cv = cv, hac = hac)
}

summarise_rep <- function(res, replicate, cv_sa = NULL) {
  out <- data.frame(replicate = replicate, K_hat = res$K,
                    hac_condition = res$hac$condition_number,
                    hac_ridge = res$hac$ridge_added, error = "",
                    stringsAsFactors = FALSE)
  for (m in METHODS) {
    p <- res$paths[[m]]
    out[[paste0("alarm_", m)]] <- det_first_crossing(p, res$cv[[m]])
    out[[paste0("max_", m)]] <- max(p, na.rm = TRUE)
    out[[paste0("alarmsa_", m)]] <- if (is.null(cv_sa)) NA_integer_ else
      det_first_crossing(p, cv_sa[[m]])
  }
  out
}
fail_row <- function(replicate, msg) {
  out <- data.frame(replicate = replicate, K_hat = NA_integer_,
                    hac_condition = NA_real_, hac_ridge = NA_real_,
                    error = msg, stringsAsFactors = FALSE)
  for (m in METHODS) { out[[paste0("alarm_", m)]] <- NA_integer_
                       out[[paste0("max_", m)]] <- NA_real_
                       out[[paste0("alarmsa_", m)]] <- NA_integer_ }
  out
}

null_one <- function(replicate, sc, seed_base) {
  set.seed(seed_base + replicate)
  x <- dc_simulate_null_scores(sc$m_fit + sc$m_calibration + sc$m_monitor,
    d = sc$d_grid, design = sc$design, eigen_profile = sc$eigen_profile)
  tryCatch(summarise_rep(run_one(sc, x), replicate),
           error = function(e) fail_row(replicate, conditionMessage(e)))
}
power_one <- function(replicate, sc, seed_base, cv_sa) {
  set.seed(seed_base + replicate)
  total <- sc$m_fit + sc$m_calibration + sc$m_monitor
  x <- dc_simulate_null_scores(total, d = sc$d_grid, design = sc$design,
                               eigen_profile = sc$eigen_profile)
  w <- if (sc$panel == "panelI") {
    ww <- numeric(sc$m_monitor)
    idx <- seq.int(101L, sc$m_monitor)
    if (sc$mechanism == "abrupt") ww[idx] <- 1 else
      ww[idx] <- seq_along(idx) / length(idx)
    ww
  } else mech_weights(sc$mechanism, sc$m_monitor)
  base <- sc$m_fit + sc$m_calibration
  x[base + seq_len(sc$m_monitor), ] <- x[base + seq_len(sc$m_monitor), , drop = FALSE] +
    outer(w, shift_vector(sc))
  tryCatch({
    r <- summarise_rep(run_one(sc, x), replicate, cv_sa = cv_sa)
    r$change_start <- which(w > 0)[1L] - 1L
    r
  }, error = function(e) { r <- fail_row(replicate, conditionMessage(e))
                           r$change_start <- NA_integer_; r })
}

run_chunks <- function(ids, fun, dir, ...) {
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  starts <- seq.int(1L, length(ids), by = args$chunk)
  res <- vector("list", length(starts))
  for (ci in seq_along(starts)) {
    first <- starts[ci]; last <- min(length(ids), first + args$chunk - 1L)
    f <- file.path(dir, sprintf("rep_%06d_%06d.rds", first, last))
    if (file.exists(f)) { res[[ci]] <- readRDS(f); next }
    res[[ci]] <- do.call(rbind, parallel::mclapply(ids[first:last], fun, ...,
                          mc.cores = args$workers, mc.preschedule = TRUE))
    saveRDS(res[[ci]], f)
  }
  do.call(rbind, res)
}

## ---- null stage -----------------------------------------------------------
if (args$stage %in% c("all", "null")) {
  rows <- list()
  for (i in seq_along(null_scenarios)) {
    sc <- null_scenarios[[i]]
    message("[null] ", sc$id, "  ", format(Sys.time(), "%H:%M:%S"))
    raw <- run_chunks(seq_len(args$nrep), null_one,
                      file.path(ckpt_dir, "null", sc$id),
                      sc = sc, seed_base = args$seed + i * 1000000L)
    saveRDS(raw, file.path(out_dir, paste0("null_", sc$id, ".rds")))
    v <- raw[raw$error == "", , drop = FALSE]
    for (m in METHODS) {
      sz <- mean(!is.na(v[[paste0("alarm_", m)]]))
      rows[[length(rows) + 1L]] <- data.frame(
        panel = sc$panel, scenario_id = sc$id, design = sc$design, method = m,
        n_valid = nrow(v), n_errors = nrow(raw) - nrow(v),
        empirical_size = sz, monte_carlo_se = sqrt(sz * (1 - sz) / nrow(v)),
        size_adjusted_critical = stats::quantile(v[[paste0("max_", m)]], 0.95,
                                                 type = 8, names = FALSE),
        K_distribution = paste0(names(table(v$K_hat)), ":",
          sprintf("%.4f", as.numeric(table(v$K_hat)) / nrow(v)), collapse = ";"),
        median_hac_condition = stats::median(v$hac_condition),
        ridge_use_rate = mean(v$hac_ridge > 0), stringsAsFactors = FALSE)
    }
  }
  utils::write.csv(do.call(rbind, rows),
    file.path(data_dir, "detector_benchmark_null_size_5000rep.csv"), row.names = FALSE)
  message("null stage written")
}

## ---- power stage ----------------------------------------------------------
if (args$stage %in% c("all", "power")) {
  nullsum <- utils::read.csv(file.path(data_dir,
    "detector_benchmark_null_size_5000rep.csv"), stringsAsFactors = FALSE)
  rows <- list()
  for (i in seq_along(power_scenarios)) {
    sc <- power_scenarios[[i]]
    ns <- nullsum[nullsum$scenario_id == sc$null_scenario_id, ]
    cv_sa <- setNames(as.list(ns$size_adjusted_critical[match(METHODS, ns$method)]), METHODS)
    message("[power] ", sc$id, "  ", format(Sys.time(), "%H:%M:%S"))
    raw <- run_chunks(seq_len(args$nrep), power_one,
                      file.path(ckpt_dir, "power", sc$id),
                      sc = sc, seed_base = args$seed + 50000000L + i * 1000000L,
                      cv_sa = cv_sa)
    saveRDS(raw, file.path(out_dir, paste0("power_", sc$id, ".rds")))
    v <- raw[raw$error == "", , drop = FALSE]
    cs <- as.integer(stats::median(v$change_start, na.rm = TRUE))
    horizon <- sc$m_monitor
    ## common no-pre-alarm risk set: replications in which NO method alarms
    ## before the change, so every method is scored on the same replications.
    pre_any <- Reduce(`|`, lapply(METHODS, function(m) {
      a <- v[[paste0("alarmsa_", m)]]; !is.na(a) & a <= cs }))
    risk <- which(!pre_any)
    for (m in METHODS) {
      an <- v[[paste0("alarm_", m)]]; asa <- v[[paste0("alarmsa_", m)]]
      post_n <- !is.na(an) & an > cs
      post_s <- !is.na(asa) & asa > cs
      d_all <- ifelse(post_s[risk], asa[risk] - cs, horizon - cs + 1L)
      d_cond <- (asa[post_s] - cs)
      rows[[length(rows) + 1L]] <- data.frame(
        panel = sc$panel, scenario_id = sc$id, design = sc$design,
        mechanism = sc$mechanism, direction = sc$direction,
        delta = sc$delta, method = m, n_valid = nrow(v),
        change_start = cs, risk_set_size = length(risk),
        nominal_critical = NA_real_,
        size_adjusted_critical = cv_sa[[m]],
        prechange_false_alarm_nominal = mean(!is.na(an) & an <= cs),
        prechange_false_alarm_sa = mean(!is.na(asa) & asa <= cs),
        nominal_detection = mean(post_n),
        size_adjusted_detection = mean(post_s),
        size_adjusted_detection_se = sqrt(mean(post_s) * (1 - mean(post_s)) / nrow(v)),
        restricted_mean_delay = mean(d_all),
        conditional_mean_delay = if (length(d_cond)) mean(d_cond) else NA_real_,
        stringsAsFactors = FALSE)
    }
  }
  utils::write.csv(do.call(rbind, rows),
    file.path(data_dir, "detector_benchmark_power_5000rep.csv"), row.names = FALSE)
  message("power stage written")
}
