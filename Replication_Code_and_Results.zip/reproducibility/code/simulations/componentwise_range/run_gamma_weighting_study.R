#!/usr/bin/env Rscript
# ---------------------------------------------------------------------------
# Boundary weight (gamma) crossed with normalizer and change timing.
#
# gamma enters the boundary, not the scale estimate, so it can be applied to the
# adjusted-range, quadratic and HAC CUSUM statistics alike.  Holding gamma fixed
# across normalizers separates the weighting scheme from the normalizer; varying
# the change timing shows which weight suits which alternative.
# ---------------------------------------------------------------------------
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
project_dir <- normalizePath(file.path(script_dir, "../.."))
paper_dir <- normalizePath(file.path(project_dir, ".."))
source(file.path(project_dir, "R", "dual_channel_monitor.R"))
source(file.path(project_dir, "simulations", "formal", "R", "null_dgp.R"))
source(file.path(script_dir, "hac_kernels.R"))
source(file.path(script_dir, "gamma_weighting.R"))

args <- list(nrep = 5000L, cv_nrep = 250000L, workers = 11L, chunk = 250L,
             seed = 20260903L, stage = "all")
for (a in commandArgs(trailingOnly = TRUE)) {
  kv <- strsplit(sub("^--", "", a), "=", fixed = TRUE)[[1L]]
  args[[kv[1L]]] <- if (kv[1L] == "stage") kv[2L] else as.integer(kv[2L])
}
out_dir <- file.path(script_dir, "outputs", "gamma_study")
ckpt <- file.path(script_dir, "checkpoints", sprintf("gamma_s%d", args$seed))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
data_dir <- file.path(paper_dir, "data")

STATS <- c("adjusted_range", "quadratic", "cusum")
DESIGNS <- c(DGP1 = "gaussian_iid", DGP2 = "hong_var_diag", DGP4 = "component_garch")
M <- 1000L; NMON <- 500L; MFIT <- 500L
## permanent shifts at three start points, common signal energy
TIMING <- c(early = 50L, middle = 250L, late = 350L)
ENERGY <- 0.15^2 * 450
timing_delta <- function(st) sqrt(ENERGY / (NMON - st))
combo <- expand.grid(stat = STATS, gamma = GAMMA_GRID, stringsAsFactors = FALSE)
combo$tag <- paste0(combo$stat, "_g", sub("\\.", "", sprintf("%.2f", combo$gamma)))

## ---- matched-grid critical values -----------------------------------------
cv_file <- file.path(out_dir, sprintf("cv_gamma_m%d_n%d_r%d.rds", M, NMON, args$cv_nrep))
if (file.exists(cv_file)) CV <- readRDS(cv_file) else {
  starts <- seq.int(1L, args$cv_nrep, by = 1000L)
  parts <- parallel::mclapply(seq_along(starts), function(ci) {
    lo <- starts[ci]; hi <- min(args$cv_nrep, lo + 999L)
    set.seed(args$seed + 900000L + ci)
    a <- array(NA_real_, dim = c(hi - lo + 1L, 3L, length(GAMMA_GRID), 5L))
    for (i in seq_len(dim(a)[1L])) a[i, , , ] <- gw_reference_one(M, NMON, 5L)
    a
  }, mc.cores = args$workers, mc.preschedule = FALSE)
  n <- sum(vapply(parts, function(p) dim(p)[1L], 1L))
  big <- array(NA_real_, dim = c(n, 3L, length(GAMMA_GRID), 5L)); o <- 0L
  for (p in parts) { idx <- o + seq_len(dim(p)[1L]); big[idx, , , ] <- p; o <- max(idx) }
  CV <- apply(big, c(2L, 3L, 4L), function(v)
    stats::quantile(v, 0.95, type = 8, names = FALSE))
  dimnames(CV) <- list(STATS, as.character(GAMMA_GRID), NULL)
  saveRDS(CV, cv_file)
}
cvtab <- do.call(rbind, lapply(STATS, function(st) do.call(rbind,
  lapply(seq_along(GAMMA_GRID), function(gi) data.frame(
    statistic = st, gamma = GAMMA_GRID[gi], K = 1:5,
    m_reference = M, n_monitor = NMON, nrep = args$cv_nrep,
    critical_value = CV[st, gi, ], stringsAsFactors = FALSE)))))
utils::write.csv(cvtab, file.path(data_dir, "gamma_weighting_critical_values.csv"),
                 row.names = FALSE)

## ---- one replication ------------------------------------------------------
shift_vec <- function(design, delta) {
  lam <- dc_score_eigenvalues(8L, profile = "fixed")
  rot <- if (design == "gaussian_iid") diag(8L) else dc_functional_basis_rotation(8L)
  as.numeric((delta * c(1, 0) * sqrt(lam[1:2])) %*% rot[1:2, , drop = FALSE])
}

one_rep <- function(rep_id, design, start, seed_base, cv_sa = NULL) {
  set.seed(seed_base + rep_id)
  x <- dc_simulate_null_scores(MFIT + M + NMON, d = 8L, design = design,
                               eigen_profile = "fixed")
  if (!is.na(start)) {
    w <- numeric(NMON); w[seq.int(start + 1L, NMON)] <- 1
    x[MFIT + M + seq_len(NMON), ] <- x[MFIT + M + seq_len(NMON), , drop = FALSE] +
      outer(w, shift_vec(design, timing_delta(start)))
  }
  tryCatch({
    fit <- dc_fit_score_comparison(x[seq_len(MFIT), , drop = FALSE],
      x[MFIT + seq_len(M), , drop = FALSE], K = 2L, fve = 0.90, K_max = 5L,
      prewhiten_mode = "demix", ldl_ridge = 1e-8, sn_ridge = 0,
      feature_var_order = 0L)
    K <- fit$settings$K
    xm <- x[MFIT + M + seq_len(NMON), , drop = FALSE]
    proj <- dc_project_fpca(fit$adjusted_range$fpca, xm)
    mf <- dc_apply_var_ldl_features(fit$adjusted_range$feature_prewhitener,
      dc_apply_ldl_prewhitener(fit$adjusted_range$prewhitener, proj$retained))
    hac <- hac_lrv(fit$adjusted_range$calibration_sn_scores, "bartlett", "fixed10")
    out <- data.frame(replicate = rep_id, K_hat = K, error = "",
                      stringsAsFactors = FALSE)
    for (gi in seq_along(GAMMA_GRID)) {
      g <- GAMMA_GRID[gi]
      p <- gw_paths(fit, hac, mf, g)
      for (st in STATS) {
        tg <- combo$tag[combo$stat == st & combo$gamma == g]
        cv <- CV[st, gi, K]
        hit <- which(p[[st]] > cv)
        out[[paste0("alarm_", tg)]] <- if (length(hit)) hit[1L] else NA_integer_
        out[[paste0("max_", tg)]] <- max(p[[st]])
        if (!is.null(cv_sa)) {
          h2 <- which(p[[st]] > cv_sa[[tg]])
          out[[paste0("alarmsa_", tg)]] <- if (length(h2)) h2[1L] else NA_integer_
        }
      }
    }
    out
  }, error = function(e) data.frame(replicate = rep_id, K_hat = NA_integer_,
                                    error = conditionMessage(e),
                                    stringsAsFactors = FALSE))
}

run_cell <- function(id, design, start, seed_base, cv_sa = NULL) {
  dir.create(file.path(ckpt, id), recursive = TRUE, showWarnings = FALSE)
  starts <- seq.int(1L, args$nrep, by = args$chunk)
  pieces <- vector("list", length(starts))
  for (si in seq_along(starts)) {
    lo <- starts[si]; hi <- min(args$nrep, lo + args$chunk - 1L)
    fp <- file.path(ckpt, id, sprintf("r_%06d_%06d.rds", lo, hi))
    if (file.exists(fp)) { pieces[[si]] <- readRDS(fp); next }
    pieces[[si]] <- do.call(rbind, parallel::mclapply(lo:hi, one_rep,
      design = design, start = start, seed_base = seed_base, cv_sa = cv_sa,
      mc.cores = args$workers, mc.preschedule = TRUE))
    saveRDS(pieces[[si]], fp)
  }
  do.call(rbind, pieces)
}

## ---- null stage -----------------------------------------------------------
nullrows <- list(); sa_cut <- list()
for (di in seq_along(DESIGNS)) {
  dg <- names(DESIGNS)[di]
  message("[gamma null] ", dg, "  ", format(Sys.time(), "%H:%M:%S"))
  raw <- run_cell(paste0("null_", dg), DESIGNS[[di]], NA_integer_,
                  args$seed + di * 100000L)
  v <- raw[raw$error == "", , drop = FALSE]
  for (i in seq_len(nrow(combo))) {
    tg <- combo$tag[i]; sz <- mean(!is.na(v[[paste0("alarm_", tg)]]))
    cut <- stats::quantile(v[[paste0("max_", tg)]], 0.95, type = 8, names = FALSE)
    sa_cut[[paste(dg, tg)]] <- cut
    nullrows[[length(nullrows) + 1L]] <- data.frame(
      dgp = dg, design = DESIGNS[[di]], statistic = combo$stat[i],
      gamma = combo$gamma[i], n_valid = nrow(v), empirical_size = sz,
      monte_carlo_se = sqrt(sz * (1 - sz) / nrow(v)),
      size_adjusted_critical = cut, stringsAsFactors = FALSE)
  }
}
utils::write.csv(do.call(rbind, nullrows),
  file.path(data_dir, "gamma_weighting_null_size_5000rep.csv"), row.names = FALSE)

## ---- power stage ----------------------------------------------------------
powrows <- list(); ci <- 0L
for (di in seq_along(DESIGNS)) for (ti in seq_along(TIMING)) {
  ci <- ci + 1L
  dg <- names(DESIGNS)[di]; tm <- names(TIMING)[ti]; st0 <- TIMING[[ti]]
  cvsa <- setNames(lapply(combo$tag, function(tg) sa_cut[[paste(dg, tg)]]), combo$tag)
  message("[gamma power] ", dg, " ", tm, "  ", format(Sys.time(), "%H:%M:%S"))
  raw <- run_cell(sprintf("power_%s_%s", dg, tm), DESIGNS[[di]], st0,
                  args$seed + 5000000L + ci * 100000L, cv_sa = cvsa)
  v <- raw[raw$error == "", , drop = FALSE]
  ## common no-pre-alarm risk set across all statistic/gamma combinations
  pre_any <- Reduce(`|`, lapply(combo$tag, function(tg) {
    a <- v[[paste0("alarmsa_", tg)]]; !is.na(a) & a <= st0 }))
  risk <- which(!pre_any); cap <- NMON - st0 + 1L
  for (i in seq_len(nrow(combo))) {
    tg <- combo$tag[i]
    a <- v[[paste0("alarm_", tg)]]; asa <- v[[paste0("alarmsa_", tg)]]
    post_n <- !is.na(a) & a > st0
    post_s <- !is.na(asa) & asa > st0
    d_all <- ifelse(post_s[risk], asa[risk] - st0, cap)
    powrows[[length(powrows) + 1L]] <- data.frame(
      dgp = dg, design = DESIGNS[[di]], timing = tm, change_start = st0,
      delta = timing_delta(st0), statistic = combo$stat[i],
      gamma = combo$gamma[i], n_valid = nrow(v), risk_set_size = length(risk),
      prechange_false_alarm_nominal = mean(!is.na(a) & a <= st0),
      prechange_false_alarm_sa = mean(!is.na(asa) & asa <= st0),
      nominal_detection = mean(post_n),
      size_adjusted_detection = mean(post_s),
      size_adjusted_detection_se = sqrt(mean(post_s) * (1 - mean(post_s)) / nrow(v)),
      restricted_mean_delay = mean(d_all),
      size_adjusted_critical = sa_cut[[paste(dg, tg)]], stringsAsFactors = FALSE)
  }
}
utils::write.csv(do.call(rbind, powrows),
  file.path(data_dir, "gamma_weighting_power_5000rep.csv"), row.names = FALSE)
message("done")
