#!/usr/bin/env Rscript
# Unit checks for the benchmark detector shapes.
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
project_dir <- normalizePath(file.path(script_dir, "../.."))
source(file.path(project_dir, "R", "dual_channel_monitor.R"))
source(file.path(script_dir, "detector_shapes.R"))
set.seed(4242)

ok <- function(label, pass, detail = "") {
  cat(sprintf("%-58s %s %s\n", label, if (pass) "PASS" else "FAIL", detail))
  if (!pass) stop("unit check failed: ", label)
}

## 1. Page/CUSUM vs a direct brute-force implementation on a small sample.
m <- 60L; n <- 25L; K <- 3L
ref  <- matrix(rnorm(m * K), ncol = K)
mon  <- matrix(rnorm(n * K), ncol = K)
hac  <- det_bartlett_lrv(ref, bandwidth = 5L)
full_lags <- seq_len(n)
fast <- det_paths(hac, mon, lag_grid = full_lags)

cen <- sweep(mon, 2L, hac$center, FUN = "-")
brute_cusum <- brute_weighted <- brute_page <- numeric(n)
for (k in seq_len(n)) {
  Sk <- colSums(cen[seq_len(k), , drop = FALSE])
  q  <- as.numeric(t(Sk) %*% hac$inverse %*% Sk) / m
  brute_cusum[k]    <- q / det_boundary_sq(k / m, 0)
  brute_weighted[k] <- q / det_boundary_sq(k / m, DETECTOR_GAMMA_WEIGHTED)
  best <- -Inf
  for (j in 0:(k - 1L)) {
    D <- colSums(cen[seq.int(j + 1L, k), , drop = FALSE])
    qq <- as.numeric(t(D) %*% hac$inverse %*% D) / m
    best <- max(best, qq / det_boundary_sq((k - j) / m, 0))
  }
  brute_page[k] <- best
}
ok("Page-CUSUM equals brute-force scan",
   max(abs(fast$page - brute_page)) < 1e-10,
   sprintf("max abs diff %.3e", max(abs(fast$page - brute_page))))
ok("CUSUM equals brute force",
   max(abs(fast$cusum - brute_cusum)) < 1e-12)
ok("weighted CUSUM equals brute force",
   max(abs(fast$weighted - brute_weighted)) < 1e-12)

## 2. MOSUM brute force.
G <- as.integer(floor(m * 0.20)); stopifnot(2L * G <= n)
one <- det_paths(hac, mon, h_set = 0.20, lag_grid = 1L)
bm <- rep(NA_real_, n)
Uc <- rbind(0, apply(cen, 2L, cumsum))
for (k in seq.int(2L * G, n)) {
  D <- Uc[k + 1L, ] - 2 * Uc[k - G + 1L, ] + Uc[k - 2L * G + 1L, ]
  bm[k] <- as.numeric(t(D) %*% hac$inverse %*% D) / G
}
ok("multiscale MOSUM equals brute force",
   max(abs(one$mosum - bm), na.rm = TRUE) < 1e-12)

## 3. MOSUM is invariant to the estimated reference mean; CUSUM/Page are not.
hac2 <- hac; hac2$center <- hac$center + 0.37
p1 <- det_paths(hac, mon, lag_grid = full_lags)
p2 <- det_paths(hac2, mon, lag_grid = full_lags)
ok("MOSUM invariant to reference-mean shift",
   max(abs(p1$mosum - p2$mosum), na.rm = TRUE) < 1e-10)
ok("CUSUM not invariant to reference-mean shift (correction needed)",
   max(abs(p1$cusum - p2$cusum)) > 1e-6)

## 4. Reference generator: zero-row and index conventions, and the fact that the
##    MOSUM reference does not depend on the B(1) correction.
lg <- det_lag_grid(40L)
set.seed(11); a <- det_reference_one(50L, 40L, 3L, lg)
ok("reference maxima finite and positive", all(is.finite(a)) && all(a > 0))
ok("reference maxima nondecreasing in K",
   all(apply(a, 1L, function(r) all(diff(r) >= -1e-12))))

## 5. Raw-statistic vs reference scaling: with Omega known and IID Gaussian
##    scores, the finite-sample statistic and the reference draw must have the
##    same distribution up to HAC estimation error.
set.seed(99)
mm <- 1000L; nn <- 500L; KK <- 2L
stat_max <- ref_max <- numeric(300L)
lgs <- det_lag_grid(nn)
for (b in seq_len(300L)) {
  z  <- matrix(rnorm((mm + nn) * KK), ncol = KK)
  h0 <- list(center = colMeans(z[seq_len(mm), , drop = FALSE]),
             inverse = diag(KK), n_reference = mm, dimension = KK)
  pp <- det_paths(h0, z[mm + seq_len(nn), , drop = FALSE], lag_grid = lgs)
  stat_max[b] <- max(pp$cusum)
  ref_max[b]  <- det_reference_one(mm, nn, KK, lgs)["cusum", KK]
}
rel <- abs(mean(stat_max) - mean(ref_max)) / mean(ref_max)
ok("CUSUM statistic and reference share scale (known Omega)", rel < 0.10,
   sprintf("mean stat %.4f vs reference %.4f (rel diff %.3f)",
           mean(stat_max), mean(ref_max), rel))
cat("\nAll detector unit checks passed.\n")
