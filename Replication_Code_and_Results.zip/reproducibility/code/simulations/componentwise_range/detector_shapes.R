# ---------------------------------------------------------------------------
# detector_shapes.R -- benchmark detector shapes on the current score stream.
#
# All detectors act on the same LDL-demixed retained-score stream produced by
# dc_fit_score_comparison(), centered at the reference-block score mean, and
# are standardized by one Bartlett long-run covariance estimate computed from
# the reference block only.  Definitions follow:
#   CUSUM / weighted CUSUM : Horvath, Huskova, Kokoszka & Steinebach (2004),
#                            boundary g_gamma(s)^2 = (1+s)^2 (s/(1+s))^(2 gamma)
#   Page-CUSUM             : Fremdt (2015); scan over segment start points
#   multiscale MOSUM       : adjacent-window contrasts over H = {0.05,0.10,0.20}
# The lag scan for Page-CUSUM uses a fixed geometric grid of 40 segment
# lengths, identical in the statistic, the null simulations, the critical-value
# simulations and every power experiment.
# ---------------------------------------------------------------------------

DETECTOR_GAMMA_WEIGHTED <- 0.45
DETECTOR_LAG_GRID_SIZE  <- 40L
DETECTOR_H_SET          <- c(0.05, 0.10, 0.20)

det_boundary_sq <- function(s, gamma = 0) {
  s <- pmax(as.numeric(s), .Machine$double.eps)
  (1 + s)^2 * (s / (1 + s))^(2 * gamma)
}

# Deterministic geometric segment-length grid, prespecified and shared by every
# stage of the study.
det_lag_grid <- function(n_monitor, size = DETECTOR_LAG_GRID_SIZE) {
  n_monitor <- as.integer(n_monitor)
  if (n_monitor <= size) return(seq_len(n_monitor))
  out <- unique(round(exp(seq(log(1), log(n_monitor), length.out = size))))
  out <- as.integer(out[out >= 1L & out <= n_monitor])
  sort(unique(out))
}

det_bartlett_lrv <- function(features, bandwidth = 10L) {
  features <- dc_assert_matrix(features, "features", min_rows = 20L)
  n <- nrow(features)
  bandwidth <- min(as.integer(bandwidth), n - 1L)
  center <- colMeans(features)
  centered <- sweep(features, 2L, center, FUN = "-")
  lrv <- crossprod(centered) / n
  for (lag in seq_len(bandwidth)) {
    weight <- 1 - lag / (bandwidth + 1)
    gamma_lag <- crossprod(
      centered[seq_len(n - lag), , drop = FALSE],
      centered[lag + seq_len(n - lag), , drop = FALSE]
    ) / n
    lrv <- lrv + weight * (gamma_lag + t(gamma_lag))
  }
  inverse <- dc_inverse_spd(lrv, ridge = 1e-8)
  list(center = center, lrv = lrv, inverse = inverse$inverse,
       ridge_added = inverse$ridge_added,
       condition_number = inverse$condition_number,
       n_reference = n, dimension = ncol(features), bandwidth = bandwidth)
}

# Returns the four HAC detector paths, each indexed by monitoring time
# k = 1,...,n_monitor (NA where a detector is not yet defined).
det_paths <- function(hac, monitoring_features, h_set = DETECTOR_H_SET,
                      gamma_weighted = DETECTOR_GAMMA_WEIGHTED,
                      lag_grid = NULL) {
  monitoring_features <- dc_assert_matrix(monitoring_features,
                                          "monitoring_features", min_rows = 1L)
  m <- hac$n_reference
  n <- nrow(monitoring_features)
  centered <- sweep(monitoring_features, 2L, hac$center, FUN = "-")
  U <- rbind(rep(0, ncol(centered)), apply(centered, 2L, cumsum))  # (n+1) x K
  s <- seq_len(n) / m
  quad <- function(D) rowSums((D %*% hac$inverse) * D) / m

  cusum_raw <- quad(U[-1L, , drop = FALSE])
  path_cusum    <- cusum_raw / det_boundary_sq(s, 0)
  path_weighted <- cusum_raw / det_boundary_sq(s, gamma_weighted)

  if (is.null(lag_grid)) lag_grid <- det_lag_grid(n)
  path_page <- rep(-Inf, n)
  for (L in lag_grid) {
    hi <- seq.int(L, n)
    D <- U[hi + 1L, , drop = FALSE] - U[hi - L + 1L, , drop = FALSE]
    cur <- quad(D) / det_boundary_sq(rep(L / m, length(hi)), 0)
    path_page[hi] <- pmax(path_page[hi], cur)
  }
  path_page[!is.finite(path_page)] <- NA_real_

  path_mosum <- rep(NA_real_, n)
  for (h in h_set) {
    G <- as.integer(floor(m * h))
    if (2L * G > n) next
    valid <- seq.int(2L * G, n)
    D <- U[valid + 1L, , drop = FALSE] -
      2 * U[valid - G + 1L, , drop = FALSE] +
      U[valid - 2L * G + 1L, , drop = FALSE]
    cur <- rowSums((D %*% hac$inverse) * D) / G
    old <- path_mosum[valid]
    path_mosum[valid] <- ifelse(is.na(old), cur, pmax(old, cur))
  }

  list(cusum = path_cusum, weighted = path_weighted,
       page = path_page, mosum = path_mosum)
}

det_first_crossing <- function(path, critical) {
  hit <- which(!is.na(path) & path > critical)
  if (length(hit)) hit[1L] else NA_integer_
}

# ---------------------------------------------------------------------------
# Matched-grid reference simulation.
#
# The monitoring contrast uses the reference-block score mean, so its limit is
# U(s) = B(1+s) - (1+s) B(1).  The reference grid is therefore simulated jointly
# with the monitoring grid.  The MOSUM double difference annihilates the
# -(1+s)B(1) term, which is verified by det_unit_checks().
# ---------------------------------------------------------------------------
det_reference_one <- function(m_reference, n_monitor, Kmax, lag_grid,
                              h_set = DETECTOR_H_SET,
                              gamma_weighted = DETECTOR_GAMMA_WEIGHTED) {
  total <- m_reference + n_monitor
  incr <- matrix(stats::rnorm(total * Kmax, sd = sqrt(1 / m_reference)),
                 ncol = Kmax)
  B <- rbind(rep(0, Kmax), apply(incr, 2L, cumsum))     # B[i+1,] = B(i/m)
  B1 <- B[m_reference + 1L, , drop = FALSE]
  s <- seq_len(n_monitor) / m_reference
  U <- B[m_reference + 1L + seq_len(n_monitor), , drop = FALSE] -
    outer(1 + s, as.numeric(B1))                        # n x K
  csq <- t(apply(U^2, 1L, cumsum))                      # n x K cumulative in K
  out <- matrix(-Inf, nrow = 4L, ncol = Kmax,
                dimnames = list(c("cusum", "weighted", "page", "mosum"), NULL))
  out["cusum", ]    <- apply(csq / det_boundary_sq(s, 0), 2L, max)
  out["weighted", ] <- apply(csq / det_boundary_sq(s, gamma_weighted), 2L, max)

  Uz <- rbind(rep(0, Kmax), U)                          # Uz[i+1,] = U(i/m), U(0)=0
  page <- matrix(-Inf, nrow = n_monitor, ncol = Kmax)
  for (L in lag_grid) {
    hi <- seq.int(L, n_monitor)
    D <- Uz[hi + 1L, , drop = FALSE] - Uz[hi - L + 1L, , drop = FALSE]
    dsq <- t(apply(D^2, 1L, cumsum)) / det_boundary_sq(L / m_reference, 0)
    page[hi, ] <- pmax(page[hi, , drop = FALSE], dsq)
  }
  out["page", ] <- apply(page, 2L, max)

  mos <- matrix(-Inf, nrow = n_monitor, ncol = Kmax)
  for (h in h_set) {
    G <- as.integer(floor(m_reference * h))
    if (2L * G > n_monitor) next
    valid <- seq.int(2L * G, n_monitor)
    D <- Uz[valid + 1L, , drop = FALSE] -
      2 * Uz[valid - G + 1L, , drop = FALSE] +
      Uz[valid - 2L * G + 1L, , drop = FALSE]
    dsq <- t(apply(D^2, 1L, cumsum)) / (G / m_reference)
    mos[valid, ] <- pmax(mos[valid, , drop = FALSE], dsq)
  }
  out["mosum", ] <- apply(mos, 2L, max)
  out
}
