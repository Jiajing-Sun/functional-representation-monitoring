#!/usr/bin/env Rscript
# Benchmark detector shapes on the S&P 500 retained-score stream.
# The FPCA representation, selected dimension, LDL transformation and score
# stream are taken unchanged from the primary analysis object; nothing is
# refitted or retuned per method.
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
project_dir <- normalizePath(file.path(script_dir, "../.."))
paper_dir <- normalizePath(file.path(project_dir, ".."))
source(file.path(project_dir, "R", "dual_channel_monitor.R"))
source(file.path(project_dir, "R", "intraday_interface.R"))
source(file.path(script_dir, "detector_shapes.R"))
data_dir <- file.path(paper_dir, "data")

BANDWIDTHS <- c(5L, 10L, 20L)
PRIMARY_BW <- 10L

analysis <- readRDS(file.path(project_dir, "empirical", "outputs",
                              "spx_score_only_range_vs_shao_analysis.rds"))
fitted <- analysis$fit
raw <- dc_read_intraday_ohlc(analysis$arguments$data_file)
curves <- dc_build_intraday_volatility_curves(raw, start_date = "2014-01-01",
  end_date = "2020-12-31", bin_minutes = 5L, min_day_coverage = 0.95,
  spline_df = 12L)
split <- dc_split_intraday_curves(curves, c("2014-01-01", "2015-12-31"),
  c("2016-01-01", "2019-12-31"), c("2020-01-01", "2020-12-31"))
K <- fitted$settings$K
dates <- split$monitor_dates

cv_det <- utils::read.csv(file.path(data_dir, "detector_benchmark_critical_values.csv"),
                          stringsAsFactors = FALSE)
cv_det <- cv_det[cv_det$configuration == "exact997_251_empirical" & cv_det$K == K, ]
cv_sn <- utils::read.csv(file.path(data_dir,
  "critical_value_grid_and_monte_carlo_checks.csv"), stringsAsFactors = FALSE)
cv_sn <- cv_sn[cv_sn$configuration == "exact997_251_empirical" & cv_sn$K == K, ]

proj <- dc_project_fpca(fitted$adjusted_range$fpca, split$x_monitor)
mon_feat <- dc_apply_var_ldl_features(fitted$adjusted_range$feature_prewhitener,
  dc_apply_ldl_prewhitener(fitted$adjusted_range$prewhitener, proj$retained))

sn <- dc_monitor_score_comparison(fitted, split$x_monitor, alpha = 0.05, gamma = 0,
  critical_values = c(
    adjusted_range = cv_sn$critical_value[cv_sn$method_id == "adjusted_range"],
    shao = cv_sn$critical_value[cv_sn$method_id == "full_matrix"]))

summarise <- function(label, path, critical, bw, cond, ridge) {
  ratio <- path / critical
  alarm <- det_first_crossing(path, critical)
  data.frame(method = label, bandwidth = bw, K = K, critical_value = critical,
    alarms = !is.na(alarm),
    alarm_index = if (is.na(alarm)) NA_integer_ else alarm,
    alarm_date = if (is.na(alarm)) NA_character_ else as.character(dates[alarm]),
    ratio_at_alarm = if (is.na(alarm)) NA_real_ else ratio[alarm],
    ratio_mar16 = ratio[which(dates == as.Date("2020-03-16"))],
    maximum_threshold_ratio = max(ratio, na.rm = TRUE),
    maximum_date = as.character(dates[which.max(ifelse(is.na(ratio), -Inf, ratio))]),
    hac_condition = cond, hac_ridge = ridge, stringsAsFactors = FALSE)
}

rows <- list(
  summarise("Adjusted-range SN", sn$path$adjusted_range,
            sn$critical_values[["adjusted_range"]], NA_integer_, NA_real_, NA_real_),
  summarise("Quadratic SN", sn$path$shao,
            sn$critical_values[["shao"]], NA_integer_, NA_real_, NA_real_))
paths <- list(adjusted_range = sn$path$adjusted_range, quadratic = sn$path$shao)

for (bw in BANDWIDTHS) {
  hac <- det_bartlett_lrv(fitted$adjusted_range$calibration_sn_scores, bandwidth = bw)
  det <- det_paths(hac, mon_feat)
  labs <- c(cusum = "HAC CUSUM", weighted = "HAC weighted CUSUM",
            page = "HAC Page-CUSUM", mosum = "HAC multiscale MOSUM")
  for (d in names(labs)) {
    rows[[length(rows) + 1L]] <- summarise(labs[[d]], det[[d]],
      cv_det$critical_value[cv_det$detector == d], bw,
      hac$condition_number, hac$ridge_added)
    if (bw == PRIMARY_BW) paths[[d]] <- det[[d]]
  }
}
out <- do.call(rbind, rows)
utils::write.csv(out, file.path(data_dir, "detector_benchmark_spx.csv"),
                 row.names = FALSE, na = "")

path_df <- data.frame(date = dates, monitor_index = seq_along(dates))
cvv <- c(adjusted_range = sn$critical_values[["adjusted_range"]],
         quadratic = sn$critical_values[["shao"]],
         setNames(cv_det$critical_value[match(c("cusum","weighted","page","mosum"),
                                              cv_det$detector)],
                  c("cusum","weighted","page","mosum")))
for (nm in names(paths)) path_df[[paste0("ratio_", nm)]] <- paths[[nm]] / cvv[[nm]]
utils::write.csv(path_df, file.path(data_dir, "detector_benchmark_spx_paths.csv"),
                 row.names = FALSE, na = "")
print(out[out$bandwidth %in% c(NA, PRIMARY_BW), c("method","critical_value","alarms",
      "alarm_date","ratio_mar16","maximum_threshold_ratio","maximum_date")],
      row.names = FALSE)
