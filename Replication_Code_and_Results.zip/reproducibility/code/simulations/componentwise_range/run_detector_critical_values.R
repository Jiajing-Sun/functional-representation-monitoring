#!/usr/bin/env Rscript
# Matched-grid reference quantiles for the benchmark detector shapes.
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
project_dir <- normalizePath(file.path(script_dir, "../.."))
paper_dir <- normalizePath(file.path(project_dir, ".."))
source(file.path(project_dir, "R", "dual_channel_monitor.R"))
source(file.path(script_dir, "detector_shapes.R"))

args <- list(nrep = 250000L, workers = 10L, chunk = 500L, seed = 20260902L)
for (a in commandArgs(trailingOnly = TRUE)) {
  kv <- strsplit(sub("^--", "", a), "=", fixed = TRUE)[[1L]]
  args[[kv[1L]]] <- as.integer(kv[2L])
}
out_dir <- file.path(script_dir, "outputs", "detector_benchmark")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

simulate_cv <- function(id, m, n, nrep, Kmax, seed) {
  cache <- file.path(out_dir, sprintf("cv_%s_n%d.rds", id, nrep))
  if (file.exists(cache)) return(readRDS(cache))
  lg <- det_lag_grid(n)
  starts <- seq.int(1L, nrep, by = args$chunk)
  pieces <- parallel::mclapply(seq_along(starts), function(ci) {
    first <- starts[ci]; last <- min(nrep, first + args$chunk - 1L)
    set.seed(seed + ci)
    acc <- array(NA_real_, dim = c(last - first + 1L, 4L, Kmax))
    for (i in seq_len(dim(acc)[1L])) acc[i, , ] <- det_reference_one(m, n, Kmax, lg)
    acc
  }, mc.cores = args$workers, mc.preschedule = FALSE)
  maxima <- do.call(function(...) abind_first(...), pieces)
  res <- list(id = id, m = m, n = n, nrep = nrep, Kmax = Kmax,
              lag_grid = lg, h_set = DETECTOR_H_SET,
              gamma_weighted = DETECTOR_GAMMA_WEIGHTED,
              values = apply(maxima, c(2L, 3L), function(v)
                stats::quantile(v, 0.95, type = 8, names = FALSE)))
  dimnames(res$values) <- list(c("cusum", "weighted", "page", "mosum"), NULL)
  saveRDS(res, cache, compress = "xz")
  res
}
abind_first <- function(...) {
  parts <- list(...)
  n <- sum(vapply(parts, function(p) dim(p)[1L], integer(1L)))
  out <- array(NA_real_, dim = c(n, dim(parts[[1L]])[2L], dim(parts[[1L]])[3L]))
  o <- 0L
  for (p in parts) { idx <- o + seq_len(dim(p)[1L]); out[idx, , ] <- p; o <- max(idx) }
  out
}

t0 <- Sys.time()
sim <- simulate_cv("exact1000_500_T0.5", 1000L, 500L, args$nrep, 5L, args$seed + 1000L)
message("simulation grid done in ", format(Sys.time() - t0))
emp <- simulate_cv("exact997_251_empirical", 997L, 251L, args$nrep, 5L, args$seed + 2000L)
message("empirical grid done in ", format(Sys.time() - t0))

tab <- do.call(rbind, lapply(list(sim, emp), function(r) {
  do.call(rbind, lapply(rownames(r$values), function(d) data.frame(
    configuration = r$id, detector = d, K = seq_len(r$Kmax),
    m_reference = r$m, n_monitor = r$n, horizon = r$n / r$m, nrep = r$nrep,
    lag_grid_size = length(r$lag_grid), h_set = paste(r$h_set, collapse = ";"),
    gamma_weighted = r$gamma_weighted,
    critical_value = as.numeric(r$values[d, ]), stringsAsFactors = FALSE)))
}))
utils::write.csv(tab, file.path(paper_dir, "data",
  "detector_benchmark_critical_values.csv"), row.names = FALSE)
print(tab[tab$K <= 4, ], row.names = FALSE)
