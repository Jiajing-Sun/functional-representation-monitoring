#!/usr/bin/env Rscript
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
paper_dir <- normalizePath(file.path(script_dir, "../../.."))
data_dir <- file.path(paper_dir, "data")
fig_dir <- file.path(paper_dir, "..", "figures", "revised")

b <- utils::read.csv(file.path(data_dir, "hac_bandwidth_sample_size_5000rep.csv"),
                     stringsAsFactors = FALSE)
ms <- sort(unique(b$m_reference))
SHOW <- c("bartlett_nw94", "bartlett_andrews91", "parzen_andrews91", "qs_andrews91")
LAB <- c(bartlett_nw94 = "Bartlett, Newey-West rate",
         bartlett_andrews91 = "Bartlett, Andrews plug-in",
         parzen_andrews91 = "Parzen, Andrews plug-in",
         qs_andrews91 = "Quadratic spectral, Andrews plug-in")
COL <- c(bartlett_nw94 = "#c62828", bartlett_andrews91 = "#2e7d32",
         parzen_andrews91 = "#7b1fa2", qs_andrews91 = "#1b6ca8")
PCH <- c(bartlett_nw94 = 8, bartlett_andrews91 = 15, parzen_andrews91 = 18,
         qs_andrews91 = 16)
DGPL <- c(DGP1 = "DGP1: Gaussian IID", DGP2 = "DGP2: diagonal VAR(0.5)",
          DGP4 = "DGP4: componentwise GARCH")

png(file.path(fig_dir, "hac_sample_size_convergence.png"),
    width = 2100, height = 830, res = 205)
op <- par(mfrow = c(1, 3), mar = c(4.3, 4.4, 2.8, 0.8), oma = c(3.4, 0, 0, 0),
          cex.axis = 0.85, cex.lab = 0.95)
for (dg in c("DGP1", "DGP2", "DGP4")) {
  d <- b[b$dgp == dg, ]
  yy <- d$empirical_size[d$method %in% SHOW]
  plot(NA, xlim = range(log(ms)), ylim = c(0.04, max(0.15, max(yy))),
       xaxt = "n", xlab = "Reference-block length m",
       ylab = if (dg == "DGP1") "Null rejection rate" else "",
       main = DGPL[[dg]], col.main = "black")
  axis(1, at = log(ms), labels = ms, col.axis = "black")
  abline(h = 0.05, lty = 2, col = "grey40")
  for (m in SHOW) {
    s <- d[d$method == m, ]
    s <- s[order(s$m_reference), ]
    lines(log(s$m_reference), s$empirical_size, col = COL[m], lwd = 1.7)
    points(log(s$m_reference), s$empirical_size, col = COL[m], pch = PCH[m], cex = 1.05)
  }
  sn <- d[d$method %in% c("adjusted_range", "quadratic") & d$m_reference == 1000, ]
  if (nrow(sn)) {
    points(rep(log(1000), nrow(sn)), sn$empirical_size, pch = 4, cex = 1.4, lwd = 2)
    text(log(1000), min(sn$empirical_size) - 0.004, "SN", cex = 0.75, col = "black")
  }
}
par(op)
par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
plot(0, 0, type = "n", bty = "n", xaxt = "n", yaxt = "n")
legend("bottom", legend = c(LAB[SHOW], "Self-normalized statistics at m = 1000"),
       col = c(COL[SHOW], "black"), pch = c(PCH[SHOW], 4), lwd = c(rep(1.7, 4), NA),
       ncol = 3, bty = "n", cex = 0.78, text.col = "black")
dev.off()
cat("figure written\n")
