#!/usr/bin/env Rscript
# Summary tables, win/loss/tie map and figures for the detector benchmark.
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
project_dir <- normalizePath(file.path(script_dir, "../.."))
paper_dir <- normalizePath(file.path(project_dir, ".."))
data_dir <- file.path(paper_dir, "data")
fig_dir <- file.path(paper_dir, "..", "figures", "revised")
tab_dir <- file.path(paper_dir, "..", "tables")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

METHODS <- c("adjusted_range", "quadratic", "cusum", "weighted", "page", "mosum")
LABEL <- c(adjusted_range = "Adjusted-range SN", quadratic = "Quadratic SN",
           cusum = "HAC CUSUM", weighted = "HAC weighted CUSUM",
           page = "HAC Page-CUSUM", mosum = "HAC multiscale MOSUM")
SHORT <- c(adjusted_range = "AR-SN", quadratic = "Q-SN", cusum = "CUSUM",
           weighted = "wCUSUM", page = "Page", mosum = "MOSUM")
DGPLAB <- c(primary_gaussian_iid = "DGP1", primary_hong_diag_var = "DGP2",
            primary_component_lrv = "DGP3", primary_component_garch = "DGP4",
            primary_component_sv = "DGP5", primary_component_t5 = "DGP6",
            primary_randomK_stable = "DGP7", primary_randomK_boundary = "DGP8",
            stress_hong_cross_var = "DGP9", stress_hong_cross_garch = "DGP10",
            stress_general_nondiag_lrv = "DGP11",
            stress_common_persistent_garch = "DGP12",
            stress_common_persistent_sv = "DGP13", stress_general_t5 = "DGP14",
            stress_general_t3 = "DGP15")
DGPSHORT <- c(gaussian_iid = "DGP1", hong_var_diag = "DGP2",
              component_garch = "DGP4", component_sv = "DGP5",
              component_t5 = "DGP6")
fmt <- function(x, d = 4) formatC(x, format = "f", digits = d)

nul <- utils::read.csv(file.path(data_dir, "detector_benchmark_null_size_5000rep.csv"),
                       stringsAsFactors = FALSE)
nul$dgp <- DGPLAB[nul$scenario_id]

## ---- Table: null size -----------------------------------------------------
wide <- reshape(nul[, c("dgp", "method", "empirical_size")],
                idvar = "dgp", timevar = "method", direction = "wide")
names(wide) <- sub("^empirical_size\\.", "", names(wide))
wide <- wide[match(paste0("DGP", 1:15), wide$dgp), ]
lines <- c("\\begin{tabular}{lrrrrrr}", "\\toprule",
  paste0("Design & ", paste(SHORT[METHODS], collapse = " & "), " \\\\"), "\\midrule")
for (i in seq_len(nrow(wide))) {
  if (i == 1L) lines <- c(lines, "\\multicolumn{7}{l}{\\textit{Primary design panel}}\\\\")
  if (i == 9L) lines <- c(lines, "\\midrule", "\\multicolumn{7}{l}{\\textit{Deliberate stress panel}}\\\\")
  lines <- c(lines, paste0(wide$dgp[i], " & ",
    paste(fmt(as.numeric(wide[i, METHODS])), collapse = " & "), " \\\\"))
}
lines <- c(lines, "\\bottomrule", "\\end{tabular}")
writeLines(lines, file.path(tab_dir, "detector_null_size.tex"))

## ---- Power ----------------------------------------------------------------
pw <- utils::read.csv(file.path(data_dir, "detector_benchmark_power_5000rep.csv"),
                      stringsAsFactors = FALSE)
pw$dgp <- DGPSHORT[pw$design]
pw$cell <- with(pw, paste(panel, mechanism, dgp, direction, sep = "|"))

## Win/loss/tie map on size-adjusted detection, paired MC standard error.
cells <- unique(pw$cell)
wl <- do.call(rbind, lapply(cells, function(cc) {
  d <- pw[pw$cell == cc, ]
  best <- d$method[which.max(d$size_adjusted_detection)]
  ar <- d$size_adjusted_detection[d$method == "adjusted_range"]
  bs <- max(d$size_adjusted_detection)
  se <- sqrt(2 * 0.25 / d$n_valid[1L])          # conservative paired SE bound
  data.frame(cell = cc, panel = d$panel[1L], mechanism = d$mechanism[1L],
             dgp = d$dgp[1L], direction = d$direction[1L], delta = d$delta[1L],
             winner = best, adjusted_range = ar, best_value = bs,
             margin = ar - bs,
             tie = abs(ar - bs) < 1.96 * se,
             stringsAsFactors = FALSE)
}))
utils::write.csv(wl, file.path(data_dir, "detector_benchmark_win_loss_map.csv"),
                 row.names = FALSE)

summary_by <- function(sub, key) {
  do.call(rbind, lapply(split(sub, sub[[key]]), function(d) {
    out <- data.frame(group = d[[key]][1L], stringsAsFactors = FALSE)
    for (m in METHODS) {
      out[[paste0("power_", m)]] <- mean(d$size_adjusted_detection[d$method == m])
      out[[paste0("delay_", m)]] <- mean(d$restricted_mean_delay[d$method == m])
    }
    out
  }))
}
p1 <- summary_by(pw[pw$panel == "panelI", ], "mechanism")
p2 <- summary_by(pw[pw$panel == "panelII", ], "mechanism")
utils::write.csv(rbind(cbind(panel = "panelI", p1), cbind(panel = "panelII", p2)),
  file.path(data_dir, "detector_benchmark_power_summary.csv"), row.names = FALSE)

## ---- Figures --------------------------------------------------------------
COL <- c(adjusted_range = "#1b6ca8", quadratic = "#d1731a", cusum = "#2e7d32",
         weighted = "#7b1fa2", page = "#c62828", mosum = "#5d4037")
PCH <- c(adjusted_range = 16, quadratic = 17, cusum = 15, weighted = 18,
         page = 8, mosum = 4)

mech_order <- c("early_permanent", "late_permanent", "epidemic", "ramp")
mech_lab <- c(early_permanent = "Early permanent", late_permanent = "Late permanent",
              epidemic = "Epidemic", ramp = "Ramp")

png(file.path(fig_dir, "detector_panelII_power.png"), width = 2100, height = 900, res = 210)
op <- par(mfrow = c(1, 3), mar = c(6.5, 4.2, 2.6, 0.8), oma = c(3.2, 0, 0, 0),
          cex.axis = 0.85, cex.lab = 0.95, col.axis = "black", col.lab = "black")
for (dg in c("DGP1", "DGP2", "DGP4")) {
  d <- pw[pw$panel == "panelII" & pw$dgp == dg, ]
  mat <- sapply(METHODS, function(m)
    d$size_adjusted_detection[match(mech_order, d$mechanism[d$method == m])
                              + which(d$method == m)[1L] - 1L])
  mat <- sapply(METHODS, function(m) {
    s <- d[d$method == m, ]; s$size_adjusted_detection[match(mech_order, s$mechanism)] })
  plot(NA, xlim = c(0.7, 4.3), ylim = c(0, 1), xaxt = "n", xlab = "",
       ylab = if (dg == "DGP1") "Size-adjusted detection probability" else "",
       main = dg, col.main = "black")
  axis(1, at = 1:4, labels = mech_lab[mech_order], las = 2, col.axis = "black")
  abline(h = 0.05, lty = 3, col = "grey50")
  for (m in METHODS) {
    lines(1:4, mat[, m], col = COL[m], lwd = 1.6)
    points(1:4, mat[, m], col = COL[m], pch = PCH[m], cex = 1.1)
  }
}
par(op)
par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
plot(0, 0, type = "n", bty = "n", xaxt = "n", yaxt = "n")
legend("bottom", legend = LABEL[METHODS], col = COL[METHODS], pch = PCH[METHODS],
       lwd = 1.6, ncol = 3, bty = "n", cex = 0.8, text.col = "black")
dev.off()

png(file.path(fig_dir, "detector_panelII_delay.png"), width = 2100, height = 900, res = 210)
op <- par(mfrow = c(1, 3), mar = c(6.5, 4.4, 2.6, 0.8), oma = c(3.2, 0, 0, 0),
          cex.axis = 0.85, cex.lab = 0.95)
for (dg in c("DGP1", "DGP2", "DGP4")) {
  d <- pw[pw$panel == "panelII" & pw$dgp == dg, ]
  mat <- sapply(METHODS, function(m) {
    s <- d[d$method == m, ]; s$restricted_mean_delay[match(mech_order, s$mechanism)] })
  plot(NA, xlim = c(0.7, 4.3), ylim = range(mat, na.rm = TRUE), xaxt = "n", xlab = "",
       ylab = if (dg == "DGP1") "Restricted mean delay" else "", main = dg, col.main = "black")
  axis(1, at = 1:4, labels = mech_lab[mech_order], las = 2, col.axis = "black")
  for (m in METHODS) {
    lines(1:4, mat[, m], col = COL[m], lwd = 1.6)
    points(1:4, mat[, m], col = COL[m], pch = PCH[m], cex = 1.1)
  }
}
par(op)
par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
plot(0, 0, type = "n", bty = "n", xaxt = "n", yaxt = "n")
legend("bottom", legend = LABEL[METHODS], col = COL[METHODS], pch = PCH[METHODS],
       lwd = 1.6, ncol = 3, bty = "n", cex = 0.8, text.col = "black")
dev.off()

## Empirical monitoring paths, split by normalizer family.
if (file.exists(file.path(data_dir, "detector_benchmark_spx_paths.csv"))) {
  sp <- utils::read.csv(file.path(data_dir, "detector_benchmark_spx_paths.csv"),
                        stringsAsFactors = FALSE)
  sp$date <- as.Date(sp$date)
  png(file.path(fig_dir, "detector_spx_paths.png"), width = 2000, height = 1000, res = 205)
  op <- par(mfrow = c(1, 2), mar = c(4.2, 4.3, 2.8, 0.8), oma = c(2.6, 0, 0, 0),
            cex.axis = 0.85, cex.lab = 0.95)
  grp <- list("Self-normalized" = c("adjusted_range", "quadratic"),
              "HAC-standardized" = c("cusum", "weighted", "page", "mosum"))
  for (g in names(grp)) {
    ms <- grp[[g]]
    yy <- sp[, paste0("ratio_", ms), drop = FALSE]
    plot(NA, xlim = range(sp$date), ylim = c(0, max(2, max(yy, na.rm = TRUE))),
         xaxt = "n", xlab = "2020",
         ylab = "Statistic / 5% critical value", main = g, col.main = "black")
    ticks <- seq(as.Date("2020-01-01"), as.Date("2020-12-01"), by = "2 months")
    axis(1, at = ticks, labels = month.abb[as.integer(format(ticks, "%m"))], col.axis = "black")
    abline(h = 1, lty = 2, col = "grey40")
    for (m in ms) lines(sp$date, sp[[paste0("ratio_", m)]], col = COL[m], lwd = 1.8)
    legend("topleft", legend = LABEL[ms], col = COL[ms], lwd = 1.8, bty = "n",
           cex = 0.78, text.col = "black")
  }
  par(op); dev.off()
}
cat("summaries and figures written\n")
