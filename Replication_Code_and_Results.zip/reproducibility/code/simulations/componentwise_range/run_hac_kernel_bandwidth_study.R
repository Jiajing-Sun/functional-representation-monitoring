#!/usr/bin/env Rscript
# ---------------------------------------------------------------------------
# Kernel and bandwidth sensitivity of the HAC CUSUM benchmark, and its
# behaviour as the reference block grows.
#
# Study A: 3 kernels x 5 bandwidth principles at the manuscript design
#          (m = 1000, n = 500), four designs, null size.
# Study B: Bartlett/Parzen/QS with rate-satisfying bandwidth rules as
#          m grows from 250 to 4000 with T = 0.5 held fixed.
# Both stages also run the two self-normalized statistics on the identical
# replication, so every comparison is paired.
# ---------------------------------------------------------------------------
script_dir <- normalizePath(dirname(sub("^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[1L])))
project_dir <- normalizePath(file.path(script_dir, "../.."))
paper_dir <- normalizePath(file.path(project_dir, ".."))
source(file.path(project_dir, "R", "dual_channel_monitor.R"))
source(file.path(project_dir, "simulations", "formal", "R", "null_dgp.R"))
source(file.path(script_dir, "detector_shapes.R"))
source(file.path(script_dir, "hac_kernels.R"))

args <- list(nrep = 5000L, cv_nrep = 250000L, workers = 11L, chunk = 250L,
             seed = 20260902L, stage = "all")
for (a in commandArgs(trailingOnly = TRUE)) {
  kv <- strsplit(sub("^--", "", a), "=", fixed = TRUE)[[1L]]
  args[[kv[1L]]] <- if (kv[1L] == "stage") kv[2L] else as.integer(kv[2L])
}
out_dir <- file.path(script_dir, "outputs", "hac_kernel_study")
ckpt <- file.path(script_dir, "checkpoints", sprintf("hac_kernel_s%d", args$seed))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
data_dir <- file.path(paper_dir, "data")

KERNELS <- c("bartlett", "parzen", "qs")
RULES_A <- c("fixed5", "fixed10", "fixed20", "nw94", "andrews91")
DESIGNS_A <- c(DGP1 = "gaussian_iid", DGP2 = "hong_var_diag",
               DGP4 = "component_garch", DGP10 = "hong_garch")
DESIGNS_B <- c(DGP1 = "gaussian_iid", DGP2 = "hong_var_diag",
               DGP4 = "component_garch")
M_GRID <- c(250L, 500L, 1000L, 2000L, 4000L)

## ---- matched-grid CUSUM critical values, one per (m, n) --------------------
cusum_cv <- function(m, n, Kmax = 5L, nrep = args$cv_nrep, seed) {
  f <- file.path(out_dir, sprintf("cv_cusum_m%d_n%d_r%d.rds", m, n, nrep))
  if (file.exists(f)) return(readRDS(f))
  starts <- seq.int(1L, nrep, by = 1000L)
  parts <- parallel::mclapply(seq_along(starts), function(ci) {
    lo <- starts[ci]; hi <- min(nrep, lo + 999L)
    set.seed(seed + ci)
    t(vapply(seq_len(hi - lo + 1L),
             function(i) hac_cusum_reference(m, n, Kmax), numeric(Kmax)))
  }, mc.cores = args$workers, mc.preschedule = FALSE)
  mx <- do.call(rbind, parts)
  v <- apply(mx, 2L, function(u) stats::quantile(u, 0.95, type = 8, names = FALSE))
  saveRDS(v, f); v
}

## ---- one replication ------------------------------------------------------
sn_cv <- utils::read.csv(file.path(data_dir,
  "critical_value_grid_and_monte_carlo_checks.csv"), stringsAsFactors = FALSE)
sn_cv <- sn_cv[sn_cv$configuration == "exact1000_500_T0.5", ]

one_rep <- function(rep_id, design, m, kernels, rules, cv_cusum, cv_sn, seed_base) {
  set.seed(seed_base + rep_id)
  m_fit <- as.integer(m / 2); n_mon <- as.integer(m / 2)
  x <- dc_simulate_null_scores(m_fit + m + n_mon, d = 8L, design = design,
                               eigen_profile = "fixed")
  tryCatch({
    fit <- dc_fit_score_comparison(
      x[seq_len(m_fit), , drop = FALSE],
      x[m_fit + seq_len(m), , drop = FALSE],
      K = 2L, fve = 0.90, K_max = 5L, prewhiten_mode = "demix",
      ldl_ridge = 1e-8, sn_ridge = 0, feature_var_order = 0L)
    K <- fit$settings$K
    xm <- x[m_fit + m + seq_len(n_mon), , drop = FALSE]
    out <- data.frame(replicate = rep_id, K_hat = K, error = "",
                      stringsAsFactors = FALSE)
    if (!is.null(cv_sn)) {
      sn <- dc_monitor_score_comparison(fit, xm, alpha = 0.05, gamma = 0,
        critical_values = c(adjusted_range = cv_sn[["adjusted_range"]],
                            shao = cv_sn[["quadratic"]]))
      out$reject_adjusted_range <- max(sn$path$adjusted_range) > cv_sn[["adjusted_range"]]
      out$reject_quadratic <- max(sn$path$shao) > cv_sn[["quadratic"]]
    }
    proj <- dc_project_fpca(fit$adjusted_range$fpca, xm)
    mf <- dc_apply_var_ldl_features(fit$adjusted_range$feature_prewhitener,
      dc_apply_ldl_prewhitener(fit$adjusted_range$prewhitener, proj$retained))
    ref <- fit$adjusted_range$calibration_sn_scores
    for (k in kernels) for (r in rules) {
      h <- hac_lrv(ref, kernel = k, rule = r)
      p <- hac_cusum_path(h, mf)
      tag <- paste0(k, "_", r)
      out[[paste0("reject_", tag)]] <- max(p) > cv_cusum[K]
      out[[paste0("bw_", tag)]] <- h$bandwidth
    }
    out
  }, error = function(e) data.frame(replicate = rep_id, K_hat = NA_integer_,
                                    error = conditionMessage(e),
                                    stringsAsFactors = FALSE))
}

run_cells <- function(cells, tag) {
  rows <- list()
  for (ci in seq_len(nrow(cells))) {
    cc <- cells[ci, ]
    m <- cc$m; n <- as.integer(m / 2)
    cv_c <- cusum_cv(m, n, 5L, seed = args$seed + 7000000L + m)
    cv_s <- if (m == 1000L) c(
      adjusted_range = sn_cv$critical_value[sn_cv$method_id == "adjusted_range" & sn_cv$K == 2],
      quadratic = sn_cv$critical_value[sn_cv$method_id == "full_matrix" & sn_cv$K == 2]) else NULL
    ks <- strsplit(cc$kernels, ";")[[1L]]; rs <- strsplit(cc$rules, ";")[[1L]]
    id <- sprintf("%s_%s_m%d", tag, cc$dgp, m)
    message("[", tag, "] ", id, "  ", format(Sys.time(), "%H:%M:%S"))
    dir.create(file.path(ckpt, id), recursive = TRUE, showWarnings = FALSE)
    starts <- seq.int(1L, args$nrep, by = args$chunk)
    pieces <- vector("list", length(starts))
    for (si in seq_along(starts)) {
      lo <- starts[si]; hi <- min(args$nrep, lo + args$chunk - 1L)
      fp <- file.path(ckpt, id, sprintf("r_%06d_%06d.rds", lo, hi))
      if (file.exists(fp)) { pieces[[si]] <- readRDS(fp); next }
      pieces[[si]] <- do.call(rbind, parallel::mclapply(lo:hi, one_rep,
        design = cc$design, m = m, kernels = ks, rules = rs,
        cv_cusum = cv_c, cv_sn = cv_s,
        seed_base = args$seed + ci * 100000L,
        mc.cores = args$workers, mc.preschedule = TRUE))
      saveRDS(pieces[[si]], fp)
    }
    raw <- do.call(rbind, pieces)
    v <- raw[raw$error == "", , drop = FALSE]
    meths <- grep("^reject_", names(v), value = TRUE)
    for (mm in meths) {
      sz <- mean(v[[mm]])
      bwcol <- sub("^reject_", "bw_", mm)
      rows[[length(rows) + 1L]] <- data.frame(
        study = tag, dgp = cc$dgp, design = cc$design, m_reference = m,
        n_monitor = n, method = sub("^reject_", "", mm),
        n_valid = nrow(v), empirical_size = sz,
        monte_carlo_se = sqrt(sz * (1 - sz) / nrow(v)),
        mean_bandwidth = if (bwcol %in% names(v)) mean(v[[bwcol]]) else NA_real_,
        stringsAsFactors = FALSE)
    }
  }
  do.call(rbind, rows)
}

res <- list()
if (args$stage %in% c("all", "A")) {
  cellsA <- data.frame(dgp = names(DESIGNS_A), design = unname(DESIGNS_A),
                       m = 1000L, kernels = paste(KERNELS, collapse = ";"),
                       rules = paste(RULES_A, collapse = ";"),
                       stringsAsFactors = FALSE)
  res$A <- run_cells(cellsA, "A_kernel_bandwidth")
  utils::write.csv(res$A, file.path(data_dir,
    "hac_kernel_bandwidth_size_5000rep.csv"), row.names = FALSE)
}
if (args$stage %in% c("all", "B")) {
  cellsB <- do.call(rbind, lapply(M_GRID, function(m)
    data.frame(dgp = names(DESIGNS_B), design = unname(DESIGNS_B), m = m,
               kernels = paste(KERNELS, collapse = ";"),
               rules = "nw94;andrews91;fixed10", stringsAsFactors = FALSE)))
  res$B <- run_cells(cellsB, "B_sample_size")
  utils::write.csv(res$B, file.path(data_dir,
    "hac_bandwidth_sample_size_5000rep.csv"), row.names = FALSE)
}
message("done")
