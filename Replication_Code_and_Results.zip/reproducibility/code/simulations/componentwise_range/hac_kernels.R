# ---------------------------------------------------------------------------
# hac_kernels.R -- kernels and bandwidth-selection principles for the HAC CUSUM
# benchmark.  All rules satisfy b -> infinity with b/m -> 0, so the estimator is
# consistent and the CUSUM limit is asymptotically pivotal; the question the
# study answers is how large m must be before that matters in finite samples.
# ---------------------------------------------------------------------------

## Kernel weights at lag j given bandwidth b.
hac_kernel_weight <- function(j, b, kernel) {
  if (kernel == "bartlett") {
    x <- j / (b + 1); ifelse(x <= 1, 1 - x, 0)
  } else if (kernel == "parzen") {
    x <- j / (b + 1)
    ifelse(x <= 0.5, 1 - 6 * x^2 + 6 * x^3, ifelse(x <= 1, 2 * (1 - x)^3, 0))
  } else if (kernel == "qs") {
    x <- j / b
    d <- 6 * pi * x / 5
    ifelse(x < 1e-4, 1, 25 / (12 * pi^2 * x^2) * (sin(d) / d - cos(d)))
  } else stop("unknown kernel: ", kernel)
}

hac_max_lag <- function(b, kernel, n) {
  if (kernel == "qs") min(n - 1L, as.integer(ceiling(6 * b)))
  else min(n - 1L, as.integer(floor(b)))
}

## Andrews (1991) AR(1) plug-in bandwidth, kernel specific.
hac_andrews_bandwidth <- function(z, kernel) {
  n <- nrow(z); num1 <- num2 <- den <- 0
  for (j in seq_len(ncol(z))) {
    y <- z[, j]; y0 <- y[-n]; y1 <- y[-1L]
    rho <- sum(y0 * y1) / max(sum(y0^2), .Machine$double.eps)
    rho <- max(min(rho, 0.97), -0.97)
    s2 <- mean((y1 - rho * y0)^2)
    num1 <- num1 + 4 * rho^2 * s2^2 / ((1 - rho)^6 * (1 + rho)^2)
    num2 <- num2 + 4 * rho^2 * s2^2 / (1 - rho)^8
    den  <- den  + s2^2 / (1 - rho)^4
  }
  a1 <- num1 / max(den, .Machine$double.eps)
  a2 <- num2 / max(den, .Machine$double.eps)
  b <- switch(kernel,
    bartlett = 1.1447 * (a1 * n)^(1 / 3),
    parzen   = 2.6614 * (a2 * n)^(1 / 5),
    qs       = 1.3221 * (a2 * n)^(1 / 5))
  max(1, min(b, n / 4))
}

## Bandwidth-selection principles.  "fixed*" do not satisfy b -> infinity and
## are reported as the finite-sample anchors used in the manuscript; "nw94" and
## "andrews91" do satisfy the rate condition.
hac_bandwidth <- function(z, rule, kernel) {
  m <- nrow(z)
  switch(rule,
    fixed5     = 5,
    fixed10    = 10,
    fixed20    = 20,
    nw94       = max(1, floor(4 * (m / 100)^(2 / 9))),
    andrews91  = hac_andrews_bandwidth(z, kernel),
    stop("unknown bandwidth rule: ", rule))
}

## Kernel HAC long-run covariance of the reference-block scores.
hac_lrv <- function(features, kernel = "bartlett", rule = "fixed10") {
  features <- dc_assert_matrix(features, "features", min_rows = 20L)
  n <- nrow(features)
  center <- colMeans(features)
  z <- sweep(features, 2L, center, FUN = "-")
  b <- hac_bandwidth(z, rule, kernel)
  L <- hac_max_lag(b, kernel, n)
  lrv <- crossprod(z) / n
  if (L >= 1L) for (j in seq_len(L)) {
    w <- hac_kernel_weight(j, b, kernel)
    if (abs(w) < 1e-12) next
    g <- crossprod(z[seq_len(n - j), , drop = FALSE],
                   z[j + seq_len(n - j), , drop = FALSE]) / n
    lrv <- lrv + w * (g + t(g))
  }
  inv <- dc_inverse_spd(lrv, ridge = 1e-8)
  list(center = center, lrv = lrv, inverse = inv$inverse,
       ridge_added = inv$ridge_added, condition_number = inv$condition_number,
       n_reference = n, dimension = ncol(features),
       bandwidth = b, max_lag = L, kernel = kernel, rule = rule)
}

## CUSUM path only (the detector reinstated in the paper).
hac_cusum_path <- function(hac, monitoring_features) {
  m <- hac$n_reference
  cen <- sweep(monitoring_features, 2L, hac$center, FUN = "-")
  U <- apply(cen, 2L, cumsum)
  s <- seq_len(nrow(cen)) / m
  rowSums((U %*% hac$inverse) * U) / m / (1 + s)^2
}

## Matched-grid reference quantile for the CUSUM functional: it depends only on
## (K, m, n), not on the kernel or bandwidth, because the limit is Omega-free.
hac_cusum_reference <- function(m, n, Kmax) {
  incr <- matrix(stats::rnorm((m + n) * Kmax, sd = sqrt(1 / m)), ncol = Kmax)
  B <- rbind(rep(0, Kmax), apply(incr, 2L, cumsum))
  B1 <- as.numeric(B[m + 1L, ])
  s <- seq_len(n) / m
  U <- B[m + 1L + seq_len(n), , drop = FALSE] - outer(1 + s, B1)
  apply(t(apply(U^2, 1L, cumsum)) / (1 + s)^2, 2L, max)
}
