#!/usr/bin/env Rscript

# Auxiliary multiscale MOSUM benchmark for the current JTSA design.
#
# This script does not reuse the old RSMS/SSMS simulations.  It applies one
# established detector shape to exactly the current FPCA/LDL score stream.  A
# Bartlett long-run covariance estimate with bandwidth 10 standardizes the
# adjacent-window contrasts, and the prespecified window fractions are
# H={0.05,0.10,0.20}.  Null and moderate-signal comparisons use 5,000
# replications by default; critical values use 250,000 matched-grid draws.

script_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_dir <- if (length(script_file)) {
  dirname(normalizePath(sub("^--file=", "", script_file[1L])))
} else normalizePath("reproducibility/code/simulations/componentwise_range")
project_dir <- normalizePath(file.path(script_dir, "../.."))
paper_dir <- normalizePath(file.path(project_dir, ".."))
source(file.path(project_dir, "R", "dual_channel_monitor.R"))
source(file.path(project_dir, "R", "intraday_interface.R"))
source(file.path(project_dir, "simulations", "formal", "R", "null_dgp.R"))

parse_args <- function(args) {
  out <- list(
    nrep_null = 5000L,
    nrep_power = 5000L,
    cv_nrep = 250000L,
    workers = max(1L, min(10L, parallel::detectCores(logical = TRUE) - 1L)),
    chunk_size = 100L,
    seed = 20260830L,
    stage = "all"
  )
  character_keys <- "stage"
  for (arg in args) {
    pair <- strsplit(sub("^--", "", arg), "=", fixed = TRUE)[[1L]]
    if (length(pair) != 2L || !pair[1L] %in% names(out)) stop("Unknown argument: ", arg)
    out[[pair[1L]]] <- if (pair[1L] %in% character_keys) {
      pair[2L]
    } else as.integer(pair[2L])
  }
  if (!out$stage %in% c("all", "critical", "null", "power", "empirical")) {
    stop("stage must be all, critical, null, power, or empirical.")
  }
  out
}

scenario <- function(id, design, panel, eigen_profile = "fixed",
                     K_mode = "fixed", K_fixed = 2L, nrep = 5000L) {
  list(
    id = id, design = design, panel = panel, eigen_profile = eigen_profile,
    K_mode = K_mode, K_fixed = as.integer(K_fixed), fve = 0.90,
    d_grid = 8L, m_fit = 500L, m_calibration = 1000L, m_monitor = 500L,
    alpha = 0.05, prewhiten_mode = "demix", ldl_ridge = 1e-8,
    feature_var_order = 0L, nrep = as.integer(nrep)
  )
}

null_scenarios <- function(nrep) list(
  scenario("primary_gaussian_iid", "gaussian_iid", "primary", nrep = nrep),
  scenario("primary_hong_diag_var", "hong_var_diag", "primary", nrep = nrep),
  scenario("primary_component_lrv", "component_ar_lrv", "primary", nrep = nrep),
  scenario("primary_component_garch", "component_garch", "primary", nrep = nrep),
  scenario("primary_component_sv", "component_sv", "primary", nrep = nrep),
  scenario("primary_component_t5", "component_t5", "primary", nrep = nrep),
  scenario(
    "primary_randomK_stable", "component_ar_lrv", "primary",
    eigen_profile = "fve_stable", K_mode = "random_fve", nrep = nrep
  ),
  scenario(
    "primary_randomK_boundary", "component_ar_lrv", "primary",
    eigen_profile = "fve_boundary", K_mode = "random_fve", nrep = nrep
  ),
  scenario("stress_hong_cross_var", "hong_var_cross", "stress", nrep = nrep),
  scenario("stress_hong_cross_garch", "hong_garch", "stress", nrep = nrep),
  scenario("stress_general_nondiag_lrv", "nondiag_lrv", "stress", nrep = nrep),
  scenario("stress_common_persistent_garch", "garch", "stress", nrep = nrep),
  scenario("stress_common_persistent_sv", "sv", "stress", nrep = nrep),
  scenario("stress_general_t5", "heavy_t5", "stress", nrep = nrep),
  scenario("stress_general_t3", "heavy_t3_stress", "stress", nrep = nrep)
)

moderate_power_scenarios <- function(nrep) {
  abrupt <- expand.grid(
    design = c(
      "gaussian_iid", "hong_var_diag", "component_garch",
      "component_sv", "component_t5"
    ),
    direction = c("sparse_first", "dense_first_two"),
    delta = 0.15,
    change_shape = "abrupt",
    stringsAsFactors = FALSE
  )
  ramp <- expand.grid(
    design = c("hong_var_diag", "component_garch", "component_t5"),
    direction = "sparse_first", delta = 0.40, change_shape = "ramp",
    stringsAsFactors = FALSE
  )
  specs <- rbind(abrupt, ramp)
  null_id <- c(
    gaussian_iid = "primary_gaussian_iid",
    hong_var_diag = "primary_hong_diag_var",
    component_garch = "primary_component_garch",
    component_sv = "primary_component_sv",
    component_t5 = "primary_component_t5"
  )
  lapply(seq_len(nrow(specs)), function(i) {
    row <- specs[i, ]
    out <- scenario(
      sprintf(
        "power_%s_%s_%s_delta_%0.2f",
        row$change_shape, row$design, row$direction, row$delta
      ),
      row$design, "power", nrep = nrep
    )
    out$direction <- row$direction
    out$delta <- as.numeric(row$delta)
    out$change_shape <- row$change_shape
    out$break_after <- 100L
    out$null_scenario_id <- unname(null_id[[row$design]])
    out
  })
}

fit_bartlett_lrv <- function(features, bandwidth = 10L) {
  features <- dc_assert_matrix(features, "features", min_rows = 20L)
  n <- nrow(features)
  bandwidth <- min(as.integer(bandwidth), n - 1L)
  center <- colMeans(features)
  centered <- sweep(features, 2L, center, FUN = "-")
  lrv <- crossprod(centered) / n
  for (lag in seq_len(bandwidth)) {
    weight <- 1 - lag / (bandwidth + 1)
    gamma_lag <- crossprod(
      centered[seq_len(n - lag), , drop = FALSE],
      centered[lag + seq_len(n - lag), , drop = FALSE]
    ) / n
    lrv <- lrv + weight * (gamma_lag + t(gamma_lag))
  }
  inverse <- dc_inverse_spd(lrv, ridge = 1e-8)
  list(
    center = center, lrv = lrv, inverse = inverse$inverse,
    ridge_added = inverse$ridge_added, condition_number = inverse$condition_number,
    n_reference = n, dimension = ncol(features), bandwidth = bandwidth
  )
}

multiscale_mosum_path <- function(fit, monitoring_features,
                                  h_set = c(0.05, 0.10, 0.20)) {
  monitoring_features <- dc_assert_matrix(
    monitoring_features, "monitoring_features", min_rows = 1L
  )
  centered <- sweep(monitoring_features, 2L, fit$center, FUN = "-")
  cumulative <- rbind(rep(0, ncol(centered)), apply(centered, 2L, cumsum))
  n_monitor <- nrow(centered)
  path <- rep(NA_real_, n_monitor)
  active_scales <- integer(n_monitor)
  for (h in h_set) {
    G <- as.integer(floor(fit$n_reference * h))
    if (2L * G > n_monitor) next
    valid <- seq.int(2L * G, n_monitor)
    contrast <- cumulative[valid + 1L, , drop = FALSE] -
      2 * cumulative[valid - G + 1L, , drop = FALSE] +
      cumulative[valid - 2L * G + 1L, , drop = FALSE]
    statistic <- rowSums((contrast %*% fit$inverse) * contrast) / G
    old <- path[valid]
    path[valid] <- ifelse(is.na(old), statistic, pmax(old, statistic))
    active_scales[valid] <- active_scales[valid] + 1L
  }
  list(path = path, active_scales = active_scales)
}

first_crossing <- function(path, critical) {
  crossing <- which(!is.na(path) & path > critical)
  if (length(crossing)) crossing[1L] else NA_integer_
}

critical_one_path <- function(m_reference, n_monitor, Kmax,
                              h_set = c(0.05, 0.10, 0.20)) {
  innovations <- matrix(stats::rnorm(n_monitor * Kmax), ncol = Kmax)
  cumulative <- rbind(rep(0, Kmax), apply(innovations, 2L, cumsum))
  maxima <- rep(-Inf, Kmax)
  for (h in h_set) {
    G <- as.integer(floor(m_reference * h))
    if (2L * G > n_monitor) next
    valid <- seq.int(2L * G, n_monitor)
    contrast <- cumulative[valid + 1L, , drop = FALSE] -
      2 * cumulative[valid - G + 1L, , drop = FALSE] +
      cumulative[valid - 2L * G + 1L, , drop = FALSE]
    cumulative_squares <- t(apply(contrast^2, 1L, cumsum)) / G
    maxima <- pmax(maxima, apply(cumulative_squares, 2L, max))
  }
  maxima
}

simulate_critical_values <- function(id, m_reference, n_monitor, nrep, Kmax,
                                     workers, chunk_size, seed, output_dir) {
  cache <- file.path(
    output_dir,
    sprintf("mosum_critical_%s_n%d_m%d_h%d_K%d.rds", id, nrep, m_reference,
            n_monitor, Kmax)
  )
  if (file.exists(cache)) return(readRDS(cache))
  starts <- seq.int(1L, nrep, by = chunk_size)
  chunks <- parallel::mclapply(
    seq_along(starts),
    function(chunk_id) {
      first <- starts[chunk_id]
      last <- min(nrep, first + chunk_size - 1L)
      set.seed(seed + chunk_id)
      ans <- matrix(NA_real_, nrow = last - first + 1L, ncol = Kmax)
      for (i in seq_len(nrow(ans))) {
        ans[i, ] <- critical_one_path(m_reference, n_monitor, Kmax)
      }
      ans
    },
    mc.cores = workers, mc.preschedule = FALSE
  )
  maxima <- do.call(rbind, chunks)
  values <- vapply(seq_len(Kmax), function(K) {
    stats::quantile(maxima[, K], 0.95, type = 8, names = FALSE)
  }, numeric(1L))
  result <- list(
    id = id, m_reference = m_reference, n_monitor = n_monitor,
    horizon = n_monitor / m_reference, nrep = nrep, Kmax = Kmax,
    h_set = c(0.05, 0.10, 0.20), values = values, maxima = maxima
  )
  saveRDS(result, cache, compress = "xz")
  result
}

monitor_scores <- function(fit, x_monitor) {
  projected <- dc_project_fpca(fit$adjusted_range$fpca, x_monitor)
  scores <- dc_apply_ldl_prewhitener(
    fit$adjusted_range$prewhitener, projected$retained
  )
  dc_apply_var_ldl_features(fit$adjusted_range$feature_prewhitener, scores)
}

fit_mosum <- function(x, sc, critical_values) {
  fit_index <- seq_len(sc$m_fit)
  reference_index <- sc$m_fit + seq_len(sc$m_calibration)
  monitoring_index <- sc$m_fit + sc$m_calibration + seq_len(sc$m_monitor)
  fitted <- dc_fit_score_comparison(
    x[fit_index, , drop = FALSE], x[reference_index, , drop = FALSE],
    K = if (sc$K_mode == "fixed") sc$K_fixed else NULL,
    fve = sc$fve, K_max = 5L, prewhiten_mode = sc$prewhiten_mode,
    ldl_ridge = sc$ldl_ridge, sn_ridge = 0,
    feature_var_order = sc$feature_var_order
  )
  K <- fitted$settings$K
  hac <- fit_bartlett_lrv(fitted$adjusted_range$calibration_sn_scores, bandwidth = 10L)
  monitoring <- monitor_scores(fitted, x[monitoring_index, , drop = FALSE])
  mosum <- multiscale_mosum_path(hac, monitoring)
  critical <- critical_values[K]
  list(
    K = K, path = mosum$path, alarm = first_crossing(mosum$path, critical),
    maximum = max(mosum$path, na.rm = TRUE), critical = critical,
    hac = hac
  )
}

run_chunks <- function(ids, fun, checkpoint_dir, workers, chunk_size, ...) {
  dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)
  starts <- seq.int(1L, length(ids), by = chunk_size)
  chunks <- vector("list", length(starts))
  for (chunk_id in seq_along(starts)) {
    first <- starts[chunk_id]
    last <- min(length(ids), first + chunk_size - 1L)
    checkpoint <- file.path(checkpoint_dir, sprintf("rep_%05d_%05d.rds", first, last))
    if (file.exists(checkpoint)) {
      chunks[[chunk_id]] <- readRDS(checkpoint)
      next
    }
    pieces <- parallel::mclapply(
      ids[first:last], fun, ..., mc.cores = workers, mc.preschedule = TRUE
    )
    chunks[[chunk_id]] <- do.call(rbind, pieces)
    saveRDS(chunks[[chunk_id]], checkpoint)
  }
  do.call(rbind, chunks)
}

null_one <- function(replicate, sc, critical_values, seed_base) {
  set.seed(seed_base + replicate)
  x <- dc_simulate_null_scores(
    sc$m_fit + sc$m_calibration + sc$m_monitor,
    d = sc$d_grid, design = sc$design, eigen_profile = sc$eigen_profile
  )
  tryCatch({
    result <- fit_mosum(x, sc, critical_values)
    data.frame(
      replicate = replicate, K_hat = result$K,
      reject = !is.na(result$alarm), first_alarm = result$alarm,
      maximum = result$maximum, critical_value = result$critical,
      hac_condition = result$hac$condition_number,
      hac_ridge = result$hac$ridge_added, error = "",
      stringsAsFactors = FALSE
    )
  }, error = function(e) data.frame(
    replicate = replicate, K_hat = NA_integer_, reject = NA,
    first_alarm = NA_integer_, maximum = NA_real_, critical_value = NA_real_,
    hac_condition = NA_real_, hac_ridge = NA_real_,
    error = conditionMessage(e), stringsAsFactors = FALSE
  ))
}

shift_vector <- function(sc) {
  lambda <- dc_score_eigenvalues(sc$d_grid, profile = sc$eigen_profile)
  rotation <- if (sc$design == "gaussian_iid") {
    diag(sc$d_grid)
  } else dc_functional_basis_rotation(sc$d_grid)
  direction <- if (sc$direction == "sparse_first") {
    c(1, rep(0, sc$K_fixed - 1L))
  } else rep(1 / sqrt(sc$K_fixed), sc$K_fixed)
  score_shift <- sc$delta * direction * sqrt(lambda[seq_len(sc$K_fixed)])
  as.numeric(score_shift %*% rotation[seq_len(sc$K_fixed), , drop = FALSE])
}

power_one <- function(replicate, sc, critical_values, empirical_critical, seed_base) {
  set.seed(seed_base + replicate)
  total <- sc$m_fit + sc$m_calibration + sc$m_monitor
  x <- dc_simulate_null_scores(
    total, d = sc$d_grid, design = sc$design, eigen_profile = sc$eigen_profile
  )
  change_start <- sc$m_fit + sc$m_calibration + sc$break_after + 1L
  rows <- change_start:total
  weight <- if (sc$change_shape == "abrupt") {
    rep(1, length(rows))
  } else seq_len(length(rows)) / length(rows)
  x[rows, ] <- x[rows, , drop = FALSE] + outer(weight, shift_vector(sc))
  tryCatch({
    result <- fit_mosum(x, sc, critical_values)
    data.frame(
      replicate = replicate, K_hat = result$K,
      alarm_nominal = first_crossing(result$path, result$critical),
      alarm_size_adjusted = first_crossing(result$path, empirical_critical),
      maximum = result$maximum, error = "", stringsAsFactors = FALSE
    )
  }, error = function(e) data.frame(
    replicate = replicate, K_hat = NA_integer_, alarm_nominal = NA_integer_,
    alarm_size_adjusted = NA_integer_, maximum = NA_real_,
    error = conditionMessage(e), stringsAsFactors = FALSE
  ))
}

args <- parse_args(commandArgs(trailingOnly = TRUE))
output_dir <- file.path(script_dir, "outputs", "mosum_benchmark")
checkpoint_dir <- file.path(
  script_dir, "checkpoints",
  sprintf("mosum_current_design_cv%d_seed%d", args$cv_nrep, args$seed)
)
data_dir <- file.path(paper_dir, "data")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)

simulation_cv <- simulate_critical_values(
  "exact1000_500_T0.5", 1000L, 500L, args$cv_nrep, 5L,
  args$workers, 500L, args$seed + 300000000L, output_dir
)
empirical_cv <- simulate_critical_values(
  "exact997_251_empirical", 997L, 251L, args$cv_nrep, 5L,
  args$workers, 500L, args$seed + 400000000L, output_dir
)
critical_table <- rbind(
  data.frame(
    configuration = simulation_cv$id, K = 1:5,
    m_reference = simulation_cv$m_reference, n_monitor = simulation_cv$n_monitor,
    horizon = simulation_cv$horizon, nrep = simulation_cv$nrep,
    h_set = "0.05;0.10;0.20", critical_value = simulation_cv$values
  ),
  data.frame(
    configuration = empirical_cv$id, K = 1:5,
    m_reference = empirical_cv$m_reference, n_monitor = empirical_cv$n_monitor,
    horizon = empirical_cv$horizon, nrep = empirical_cv$nrep,
    h_set = "0.05;0.10;0.20", critical_value = empirical_cv$values
  )
)
utils::write.csv(
  critical_table, file.path(data_dir, "mosum_matched_grid_critical_values.csv"),
  row.names = FALSE
)

null_specs <- null_scenarios(args$nrep_null)
null_raw <- list()
if (args$stage %in% c("all", "null", "power")) {
  for (i in seq_along(null_specs)) {
    sc <- null_specs[[i]]
    message("MOSUM null: ", sc$id)
    raw <- run_chunks(
      seq_len(sc$nrep), null_one,
      file.path(checkpoint_dir, "null", sc$id),
      args$workers, args$chunk_size,
      sc = sc, critical_values = simulation_cv$values,
      seed_base = args$seed + i * 1000000L
    )
    null_raw[[sc$id]] <- raw
    saveRDS(raw, file.path(output_dir, paste0(sc$id, "_raw.rds")))
  }
  null_summary <- do.call(rbind, lapply(seq_along(null_specs), function(i) {
    sc <- null_specs[[i]]
    raw <- null_raw[[sc$id]]
    valid <- raw[raw$error == "", , drop = FALSE]
    size <- mean(valid$reject)
    data.frame(
      panel = sc$panel, scenario_id = sc$id, design = sc$design,
      n_valid = nrow(valid), n_errors = nrow(raw) - nrow(valid),
      empirical_size = size,
      monte_carlo_se = sqrt(size * (1 - size) / nrow(valid)),
      K_distribution = paste0(
        names(table(valid$K_hat)), ":",
        sprintf("%.4f", as.numeric(table(valid$K_hat)) / nrow(valid)),
        collapse = ";"
      ),
      median_hac_condition = stats::median(valid$hac_condition),
      ridge_use_rate = mean(valid$hac_ridge > 0),
      stringsAsFactors = FALSE
    )
  }))
  utils::write.csv(
    null_summary, file.path(data_dir, "mosum_null_size_5000rep.csv"),
    row.names = FALSE
  )
}

if (args$stage %in% c("all", "power")) {
  power_specs <- moderate_power_scenarios(args$nrep_power)
  design_order <- unique(vapply(power_specs, `[[`, character(1L), "design"))
  power_summary <- lapply(seq_along(power_specs), function(i) {
    sc <- power_specs[[i]]
    null_values <- null_raw[[sc$null_scenario_id]]
    if (is.null(null_values)) {
      null_values <- readRDS(file.path(output_dir, paste0(sc$null_scenario_id, "_raw.rds")))
    }
    null_values <- null_values[null_values$error == "" & null_values$K_hat == 2L, ]
    empirical_critical <- stats::quantile(
      null_values$maximum, 0.95, type = 8, names = FALSE
    )
    message("MOSUM power: ", sc$id)
    raw <- run_chunks(
      seq_len(sc$nrep), power_one,
      file.path(checkpoint_dir, "power", sc$id),
      args$workers, args$chunk_size,
      sc = sc, critical_values = simulation_cv$values,
      empirical_critical = empirical_critical,
      seed_base = args$seed + 100000000L +
        match(sc$design, design_order) * 1000000L
    )
    saveRDS(raw, file.path(output_dir, paste0(sc$id, "_raw.rds")))
    valid <- raw[raw$error == "", , drop = FALSE]
    alarm <- valid$alarm_size_adjusted
    pre <- !is.na(alarm) & alarm <= sc$break_after
    post <- !is.na(alarm) & alarm > sc$break_after
    at_risk <- !pre
    cap <- sc$m_monitor - sc$break_after + 1L
    restricted <- ifelse(post[at_risk], alarm[at_risk] - sc$break_after, cap)
    data.frame(
      scenario_id = sc$id, design = sc$design,
      change_shape = sc$change_shape, direction = sc$direction,
      delta_standardized = sc$delta, n_valid = nrow(valid),
      empirical_critical = empirical_critical,
      prechange_false_alarm = mean(pre),
      postchange_detection_probability = mean(post),
      conditional_postchange_power = sum(post) / sum(at_risk),
      restricted_mean_delay = mean(restricted),
      mean_delay_conditional = if (any(post)) {
        mean(alarm[post] - sc$break_after)
      } else NA_real_,
      stringsAsFactors = FALSE
    )
  })
  power_summary <- do.call(rbind, power_summary)
  utils::write.csv(
    power_summary, file.path(data_dir, "mosum_moderate_power_5000rep.csv"),
    row.names = FALSE
  )
}

if (args$stage %in% c("all", "empirical")) {
  analysis_file <- file.path(
    project_dir, "empirical", "outputs", "spx_score_only_range_vs_shao_analysis.rds"
  )
  analysis <- readRDS(analysis_file)
  fitted <- analysis$fit
  data_file <- analysis$arguments$data_file
  raw <- dc_read_intraday_ohlc(data_file)
  curves <- dc_build_intraday_volatility_curves(
    raw, start_date = "2014-01-01", end_date = "2020-12-31",
    bin_minutes = 5L, min_day_coverage = 0.95, spline_df = 12L
  )
  split <- dc_split_intraday_curves(
    curves, c("2014-01-01", "2015-12-31"),
    c("2016-01-01", "2019-12-31"), c("2020-01-01", "2020-12-31")
  )
  hac <- fit_bartlett_lrv(
    fitted$adjusted_range$calibration_sn_scores, bandwidth = 10L
  )
  monitoring <- monitor_scores(fitted, split$x_monitor)
  path <- multiscale_mosum_path(hac, monitoring)$path
  critical <- empirical_cv$values[fitted$settings$K]
  alarm <- first_crossing(path, critical)
  empirical_table <- data.frame(
    method = "HAC multiscale MOSUM", K = fitted$settings$K,
    bandwidth = 10L, h_set = "0.05;0.10;0.20",
    critical_value = critical, alarm_index = alarm,
    alarm_date = if (is.na(alarm)) NA_character_ else
      as.character(split$monitor_dates[alarm]),
    maximum_threshold_ratio = max(path / critical, na.rm = TRUE),
    maximum_date = as.character(split$monitor_dates[which.max(path)]),
    hac_condition = hac$condition_number, hac_ridge = hac$ridge_added,
    stringsAsFactors = FALSE
  )
  utils::write.csv(
    empirical_table, file.path(data_dir, "spx_mosum_benchmark.csv"),
    row.names = FALSE, na = ""
  )
}

message("Wrote current-design MOSUM benchmark outputs to ", data_dir)
