# ---------------------------------------------------------------------------
# gamma_weighting.R -- the boundary weight is orthogonal to the normalizer.
#
# Every cumulative monitoring statistic here divides its quadratic form by
#   g_gamma(s)^2 = (1+s)^2 (s/(1+s))^(2 gamma),
# so gamma is a property of the boundary, not of how the scale is estimated.
# Applying a common gamma grid to the adjusted-range, quadratic and HAC CUSUM
# statistics separates the weighting scheme from the normalizer.
#
# One Brownian path yields the reference functional for all three statistics at
# every gamma, so the matched-grid critical values are exactly paired.
# ---------------------------------------------------------------------------

GAMMA_GRID <- c(0, 0.25, 0.45)

## Reference maxima for the three normalizers on a shared matched grid.
## Returns an array [statistic, gamma, K].
gw_reference_one <- function(m, n, Kmax, gammas = GAMMA_GRID) {
  incr <- matrix(stats::rnorm((m + n) * Kmax, sd = sqrt(1 / m)), ncol = Kmax)
  B <- rbind(rep(0, Kmax), apply(incr, 2L, cumsum))
  B1 <- as.numeric(B[m + 1L, ])
  r <- seq_len(m) / m
  ## reference-block bridge, used by both self-normalizers
  B0 <- B[2L:(m + 1L), , drop = FALSE] - outer(r, B1)
  Rk <- apply(B0, 2L, max) - apply(B0, 2L, min)          # coordinate ranges
  s <- seq_len(n) / m
  U <- B[m + 1L + seq_len(n), , drop = FALSE] - outer(1 + s, B1)

  out <- array(NA_real_, dim = c(3L, length(gammas), Kmax),
               dimnames = list(c("adjusted_range", "quadratic", "cusum"),
                               as.character(gammas), NULL))
  ## adjusted-range: sum_j U_j^2 / R_j^2 ; CUSUM: sum_j U_j^2 (Omega cancels)
  ar_terms <- t(apply(sweep(U^2, 2L, Rk^2, FUN = "/"), 1L, cumsum))
  cu_terms <- t(apply(U^2, 1L, cumsum))
  for (K in seq_len(Kmax)) {
    ## quadratic: U' V^{-1} U with V the integrated bridge outer product
    V <- crossprod(B0[, seq_len(K), drop = FALSE]) / m
    Vi <- tryCatch(solve(V), error = function(e) MASS::ginv(V))
    UK <- U[, seq_len(K), drop = FALSE]
    q_terms <- rowSums((UK %*% Vi) * UK)
    for (gi in seq_along(gammas)) {
      b <- (1 + s)^2 * (s / (1 + s))^(2 * gammas[gi])
      out["adjusted_range", gi, K] <- max(ar_terms[, K] / b)
      out["quadratic", gi, K]      <- max(q_terms / b)
      out["cusum", gi, K]          <- max(cu_terms[, K] / b)
    }
  }
  out
}

## Observed monitoring paths for the three normalizers at one gamma.
## fit: dc_fit_score_comparison object; hac: hac_lrv object on the same scores.
gw_paths <- function(fit, hac, monitor_features, gamma) {
  m <- hac$n_reference
  s <- seq_len(nrow(monitor_features)) / m
  b <- (1 + s)^2 * (s / (1 + s))^(2 * gamma)
  cen <- sweep(monitor_features, 2L, hac$center, FUN = "-")
  U <- apply(cen, 2L, cumsum)
  list(
    adjusted_range = dc_sn_monitor_path(fit$adjusted_range$sn,
                                        monitor_features, gamma = gamma),
    quadratic      = dc_sn_monitor_path(fit$shao$sn,
                                        monitor_features, gamma = gamma),
    cusum          = rowSums((U %*% hac$inverse) * U) / m / b)
}
