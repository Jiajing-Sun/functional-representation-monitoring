# Replication materials

## Three-dimensional empirical visualization

`empirical/build_spx_3d_multimedia.R` (under `reproducibility/code/`)
rebuilds the paper's daily log realized-variance profiles and generates
Movie S1 and two static views. Run it from the repository or replication-package
root with `SPX_DATA_FILE` set to the licensed input path:

```sh
Rscript reproducibility/code/empirical/build_spx_3d_multimedia.R
```

The script verifies the reconstructed scores against the saved continuous
analysis and marks the first alarms on 25 March and 4 May 2020. It does not
re-estimate the monitors. Full instructions are in `multimedia/README.md`
at the package root. Use `--video=false` if ffmpeg is unavailable.

This directory contains the numerical results and code for the manuscript.
Paths below are relative to this directory unless otherwise stated.
Detailed execution instructions, dependencies and the required working
directories are in [code/README.md](code/README.md). The LaTeX source archive
is a separate package; it does not include the numerical replication files.

## Directory structure

- `data/`: saved CSV results and empirical summaries.
- `code/`: monitoring, simulation, empirical-analysis and verification scripts.
- `../tables/` and `../figures/revised/`: LaTeX tables and figures in the manuscript directory.
- `../build_revised_tables.R`: regenerates the original cell-level tables.
  Run the later presentation builders described in the code README afterwards.

The commercially licensed minute-level TickData observations are not
redistributed. Set `SPX_DATA_FILE` as described in the code README when
rerunning analyses that read the raw observations. Derived results do not
replace the licensed input for a full raw-data replication.

## Continuous 2019–2020 analysis

Run from the manuscript directory, as described in the code README:

```sh
Rscript reproducibility/code/empirical/run_spx_continuous_2019_2020.R
Rscript reproducibility/code/empirical/check_spx_continuous_outputs.R
Rscript reproducibility/code/empirical/build_spx_continuous_outputs.R
```

The runner reconstructs original scores from the saved FPCA output and
re-estimates reference quantities for each specified design. Earlier common
centering cancels exactly under recentering, avoiding use of later observations
in the new reference estimates. The checks verify the first Brownian draws
against the statistic implementation, common-centering invariance and
first-crossing inequalities. The runner also checks the 2019 statistic
prefix against the saved one-year path. The builder converts saved results
into tables and figures without changing numerical values.

The continuous files are under `data/` with prefix `spx_continuous_`
and suffixes `scores.csv`, `critical_values.csv`, `alarms.csv`,
`paths.csv`, `contributions.csv`, `correlation.csv`,
`reference_annual.csv`, `reference_acf.csv`, `normalizers.csv`,
`inverse_ldl.csv` and `loadings.csv`.
Fitted objects, simulated maxima and R session information are under
`code/empirical/outputs/continuous_2019_2020/`.
Each of the three designs uses 250,000 paired Brownian draws.

## Simulation settings and saved-output checks

The simulation base seed is 20260830; critical values use deterministic
offsets by dimension. Primary simulation and earlier 2020-only empirical
critical values use 250,000 draws. The historical 2019 and coarser-grid
calculations use 50,000; auxiliary preprocessing configurations use 20,000
unless primary critical values apply. Additional reference-window studies
use 250,000 draws for each window.

The saved null output contains 30 method-by-design rows with 5,000 valid
replications per row and no recorded errors. Alternative results contain
39 cells with 5,000 valid paired replications per cell (195,000 total), with
no recorded errors. Continuous empirical paths have 500 ordered trading
dates; earlier 2020-only paths have 251.

## File-to-result map

All paths in the second column are relative to `data/`.
The older empirical files support supplementary Appendix E; the continuous
analysis uses the files listed above.

| Result | File or directory |
| --- | --- |
| Brownian critical values, Monte Carlo intervals and grid-sensitivity results | `critical_value_grid_and_monte_carlo_checks.csv` |
| Method-specific null sizes, Monte Carlo standard errors and FVE frequencies | `paired_null_size_primary5000_stress5000.csv` |
| Paired null differences and intervals | `paired_null_differences_primary5000_stress5000.csv` |
| Method-specific nominal and size-adjusted power and delay | `paired_power_summary_5000rep.csv` |
| Paired cell-level power intervals and common-risk delay differences | `paired_power_differences_5000rep.csv` |
| SPX block sizes, horizon, selected K and normalizer checks | `spx_score_only_range_vs_shao_fit_summary.csv` |
| Earlier 2020-only FVE, LRV diagnostic, critical values and numerical safeguards | `spx_score_only_protocol_checks.csv` |
| SPX LRV-correlation diagnostic across Bartlett bandwidths | `spx_lrv_correlation_sensitivity.csv` |
| SPX alarm dates, critical values and maxima | `spx_score_only_range_vs_shao_alarms.csv` |
| All 251 earlier 2020-only daily path values | `spx_score_only_range_vs_shao_path.csv` |
| Daily coverage counts | `spx_intraday_curve_qc.csv` |
| Controlled post-LDL correlation sweep | `post_ldl_correlation_sweep_5000rep.csv` |
| Empirical-dimension short-horizon size check | `k4_short_horizon_size_5000rep.csv` |
| Boundary-FVE PC3 and near-eigengap power checks | `boundary_fve_pc3_power_5000rep.csv`; `near_eigengap_null_power_5000rep.csv` |
| SPX retained eigenfunctions, fixed-K results and coordinate contributions | `spx_retained_eigenfunctions.csv`; `spx_fpca_dimension_diagnostics.csv`; `spx_fixed_k_sensitivity.csv`; `spx_alarm_coordinate_contributions.csv` |
| Reference-block, historical-monitoring, preprocessing and reconstruction checks | `spx_robustness_checks/` |
| Different-regime LDL experiment and fixed rotation | `nonidentity_ldl_null_5000rep.csv`; `fixed_functional_rotation_8.csv` |
| Original and demixed empirical loadings | `spx_original_and_demixed_loadings.csv`; `spx_inverse_ldl_matrix.csv` |
| Fitted-direction sensitivity | `spx_fit_block_bootstrap_stability.csv`; `spx_pc34_rotation_sensitivity.csv` |
| Alternative historical reference windows | `spx_reference_window_sensitivity.csv`; `spx_reference_window_paths.csv` |
| Complete preprocessing and critical-value uncertainty | `spx_preprocessing_complete.csv`; `spx_critical_value_alarm_sensitivity.csv` |
