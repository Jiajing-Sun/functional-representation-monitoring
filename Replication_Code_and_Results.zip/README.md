# Replication materials — 9 September 2026

This package accompanies *Adjusted-Range Self-Normalization for Sequential
Monitoring of Functional Principal Component Score Means*. The LaTeX sources
and submission PDFs are supplied separately.

Start with [the numerical-result map](reproducibility/README.md) and
[the code instructions](reproducibility/code/README.md). Those instructions
specify the working directory for each command. From this package root,
the following checks use saved outputs and do not require the licensed input:

```sh
Rscript reproducibility/code/tests/test_dual_channel_monitor.R
Rscript reproducibility/code/empirical/check_spx_continuous_outputs.R
```

The primary application monitors 2019–2020 continuously using the 2014–2015
FPCA fit and 2016–2018 reference sample. The older 2020-only results belong
to supplementary Appendix E, not to the primary specification.

The core implementation retains legacy helper functions for compatibility;
their presence does not make them part of the manuscript's score-mean test.
The [multimedia instructions](multimedia/README.md) describe Movie S1 and its
reproduction. Raw licensed TickData observations are not included. Full
raw-data replication and regeneration of the surface movie require access
to those observations under the provider's terms.

Table and figure builders reproduce numerical content. The separate LaTeX
source archive contains the final journal-facing wording and layout.
